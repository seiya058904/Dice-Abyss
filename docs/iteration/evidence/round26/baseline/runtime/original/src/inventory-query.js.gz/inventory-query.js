import {itemStats,itemValue} from './equipment.js';

// Search is a transient view choice. It never changes the owned item array,
// its order, a transaction's targets, or a saved field.
export const inventoryQuery = value => typeof value === 'string' ? value.trim() : '';
export const INVENTORY_DEFENSE_FILTERS = Object.freeze([
  Object.freeze({key:'regen',label:'存活恢复'}),
  Object.freeze({key:'barrier',label:'开战护盾'}),
  Object.freeze({key:'reduction',label:'基础减伤'}),
]);
export const inventoryDefense = value => INVENTORY_DEFENSE_FILTERS.some(filter => filter.key === value) ? value : '';

export function selectInventoryItems(items, ui = {}) {
  const query = inventoryQuery(ui.inventoryQuery).toLowerCase(), defense = inventoryDefense(ui.inventoryDefense);
  return items.filter(item => (!ui.inventorySlot || item.slot === ui.inventorySlot)
    && (ui.inventoryRarity == null || ui.inventoryRarity === '' || item.rarity === Number(ui.inventoryRarity))
    && (!query || item.name.toLowerCase().includes(query))
    // itemStats preserves legacy effects and is only read for remaining matches.
    // A trait's presence does not promise an uncapped gain in the current build.
    && (!defense || itemStats(item)[defense] > 0))
    .toSorted((a, b) => ui.inventorySort === 'rarity' ? b.rarity - a.rarity || itemValue(b) - itemValue(a)
      : ui.inventorySort === 'level' ? b.level - a.level || itemValue(b) - itemValue(a)
      : itemValue(b) - itemValue(a));
}
