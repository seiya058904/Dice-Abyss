# 完整包审计 · Round22 / v5.22.0

只交付一个完整项目ZIP，严格 `<50,000,000` 十进制字节，目标≤40,000,000。源码、字体及许可、测试、必要夹具和启动入口均在该包中；无补丁链、第二证据ZIP、浏览器二进制、node_modules、用户profile或包外运行资产。

## 输入与保全

输入 `Dice-Abyss-v5.21.0-cloud-round-21(1).zip`：**34,026,997字节**、2,945文件、97,050,370展开字节；SHA-256 `fcedf5465ceeed9f2a61c79162bb203c5a2bab105feab6590cc02e7c164f76b4`。原清单2,944非自身条目与全部路径通过；CRC、穿越、case/device名、软链、加密、压缩比和总预算检查通过。只读输入在全部执行后2,945文件与路径集完全不变。

旧86测试模块、2测试夹具、129个旧脚本和8字体/许可逐字保留。包括历史自然失败存档、完整expected/事务异常与旧迁移复现材料；不是为了缩小包而删保障。版本package/release/index一致5.22.0。详见 [保全记录](evidence/round22/package/resource-preservation.json) 与 [SOURCE-INTEGRITY](evidence/round22/verification/SOURCE-INTEGRITY.json)。

## 有依据的减重

| 项目 | 处理 | 实际体积与限制 |
| --- | --- | --- |
| 16个较大历史FILE_MANIFEST | 精确gzip，保留原路径/bytes/SHA映射和恢复器 | 原3,310,321→gzip891,778字节；加映射/脚本/说明18,845后，净减少展开文件 **2,399,698字节** |
| ZIP压缩影响 | 原JSON在输入ZIP内已经deflate | 16成员压缩载荷估计反而+7,344字节再加头部；不能说下载减少2.4MB |
| 输入当前12份交接文档 | 原样gzip归档，最新文件更新到本轮 | 原737,132→gzip222,269字节；原始SHA见input-handoff-archives.json |
| 本轮测试/自然策略 | 全部stdout/stderr/TAP、两版完整report与22份原始save，较大文本无损gzip | verification目录73文件 **845,048字节**；原70证据恢复逐份核SHA，另3为索引/映射/唯一源码表 |
| 正式策略partial | 与最终报告中的四个journey逐字段完全相同 | 省掉重复副本，保留partial原SHA/大小/metadata/相等证明，未丢独立失败 |
| 视觉证据 | 保留实际选中方案和最终两变体桌面/窄屏JPEG | 未把未采用的视觉草稿变成游戏资源；不批量新增大PNG |
| 长程恢复追踪 | 原始完整JSONL/report用xz无损保存 | 保留原始gzip与展开SHA、新xz SHA、实际逐字恢复校验；没有裁剪库存/未知字段/失败 |

16历史清单实际还原16/16，空目录之外拒绝覆盖；依赖扫描确认没有原测试或脚本读取被压缩路径。三个重要大回收夹具以及历史自然失败保留，没有假称发现图像重复就删除资产。压缩详情与恢复命令见 [package/README](evidence/round22/package/README.md)。

## 运行资源预算

[src完整差异](evidence/round22/package/runtime-diff.json)：68→69文件、9,696,629→9,704,566字节，净增 **7,937字节**，无运行文件删除。唯一新增模块为2,655字节的inventory-render；深层CSS净增312字节。GPU骰子、特效模块、位图、字体和许可原字节保持，无新增运行依赖/外部请求。

所有本轮原始证据包含来源、实际字节和SHA；大文本原字节通过gzip/xz验证。来源机器绝对路径只是记录，不是启动依赖。轻量旧运行overlay恢复器已实际70/70还原index/package/src并拒绝非空目录；它不是另一个旧完整项目，也不需要用户寻找前序ZIP才能启动当前版。

## 清单、实体检查与非自引用身份

`FILE_MANIFEST.json`列最终相对路径、bytes及SHA，按完整路径字符串稳定排序，只排除清单自身。打包器纳入所有项目文件，拒绝软链和临时缓存/外部依赖目录；使用单根`Dice-Abyss/`普通ZIP。原 `scripts/verify-package.py` 的50,000,000压缩上限、100,000,000展开上限和10,000条目上限没有放宽。

**首个实体候选的全新解压门禁已实际通过。** 原验证器CRC/安全预检/全清单/空目录提取成功；新目录163模块check、完整npm test（90模块、实际840/840项）、65个HTTP资源全文SHA与10个私有路径拒绝检查通过，301个执行文件前后不变。实际原始日志见 [完整门禁映射](evidence/round22/package/fresh-source-gate/PACKAGE-MAP.json)。只修改报告或标准ZIP注释后的最终重封装，须再次CRC/清单，并证明所有运行文件、脚本和测试与刚刚在全新目录实际测试的版本逐字相同。

输出ZIP自身的精确`bytes`、`decimalMB`、`files`、`expandedBytes`和相对输入增长率，在打包和门禁完成后写入标准ZIP注释，并在最终交付答复中列明；**ZIP SHA-256只在交付答复**。注释不作为清单内文件，从而不伪造清单自哈希。当前文档不将工作目录估算写成正式压缩大小。最终实测若达到上限就不能交付。

完整成品可用`npm start`启动，不需下载测试浏览器或安装npm运行包。下一轮直接使用本ZIP和同一任务书，索引以STATE/LATEST_REPORT/VERIFY/NEXT_ROUND为准。
