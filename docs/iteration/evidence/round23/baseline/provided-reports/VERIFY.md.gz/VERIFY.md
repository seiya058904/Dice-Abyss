# 验收记录 · Round22 / v5.22.0

> **全新解压的源码门禁已通过；正式长策略仍为2/4，不能写成全面零失败。**
>
> 第一实体候选经原验证器解压到空目录后，163语法模块、完整npm test（90模块、实际840/840项）和65个HTTP资源全文SHA、10个私有路径探针通过，301个执行文件全程不变。报告回填后的正式ZIP再验CRC/清单/新提取与逐字执行身份；最终精确ZIP身份和绑定结果在ZIP注释及交付回执，ZIP自哈希不写进自身。

2026-10-19 UTC。输入为本次上传的 **5.21.0 / Round21**，当前 **5.22.0 / Round22**，存档 schema 仍为 **5**。本文只计本轮实际重新执行的检查；旧 Round21 验收原文完整保存在 [round21-verify.md.gz](archives/round21-verify.md.gz)。

**完整测试 PASS；标准 1000+50 PASS；原固定 4×400 长策略 INCOMPLETE，退出 2。** 两个长程失败样本和完整原始报告均保留，本轮不能描述为“零失败全面通过”。

## 1. 输入身份与当前冻结

输入 ZIP 为 34,026,997 字节，SHA-256 `fcedf5465ceeed9f2a61c79162bb203c5a2bab105feab6590cc02e7c164f76b4`。本轮核对全部 2,944 个非自身 manifest 条目，字节、SHA、路径集和排序通过。展开后的 2,945 个文件、97,050,370 字节保持只读，最后复查所有文件字节及路径集不变。

当前离线门禁冻结 **300 文件**：全部 src/scripts/tests，入口、package、README，以及三份必需历史协议/回归材料。完整测试结束和两模拟结束各复查一次，300/300 字节不变。输入的 **86 个原测试模块、全部夹具、129 个继承脚本**保持原字节，原 811 案例的逐模块原生计数也全部不变。

[SOURCE-INTEGRITY.json](evidence/round22/verification/SOURCE-INTEGRITY.json) 保留每个唯一冻结路径的 bytes/SHA、两次复核结果和原始证据 SHA，并明确标为省去重复继承清单的精简投影。原生逐模块源码 SHA 另随实际 TAP 摘要保留。

## 2. 完整测试与标准短程：两版本轮重跑

| 检查口径 | 输入 5.21.0 | 当前 5.22.0 |
|---|---:|---:|
| npm run check | 159 语法模块，退出 0 | 163 语法模块，退出 0 |
| npm test 默认文件包装层 | 86/86，退出 0 | 90/90，退出 0 |
| Node 逐模块原生 TAP | 86 模块、811/811 案例 | 90 模块、840/840 案例 |
| 标准 1000 次，每次 10 层 | 1000/1000，全部 0 死亡 | 1000/1000，全部 0 死亡 |
| 脚本内额外 50 次不购物 | 50/50，全部 0 死亡 | 50/50，全部 0 死亡 |

两版原生 fail/cancelled/skipped/todo 均为 0。当前新增 **29 案例**：深层两变体 15、背包局部范围 2、卡渲染 5、选区 7，811+29=840。默认包装数 90 与原生细项 840 不能相加为一个虚构总数。

当前回执时间范围为 14:15:10Z 至 14:24:02Z，完整 stdout/stderr 全保留。以下只记录执行成本：

| 墙钟秒 | 输入 | 当前 |
|---|---:|---:|
| 语法 | 6.0832 | 6.0333 |
| 默认完整测试 | 86.1739 | 97.0813 |
| 原生细项 | 88.2298 | 98.3492 |
| 标准 1000+50 | 231.1750 | 257.5436 |
| 原固定长策略 | 482.4147 | 285.3417 |

当前默认/原生测试并行，之后短程/长程并行，并可能与根流程浏览器功能检查重叠。**这些墙钟不能作基线提速比较；当前长程更早停止，也只完成较少层数。** 正式性能使用另一组隔离窗口，见 [PERFORMANCE](PERFORMANCE.md)。

短程当前 stdout **9,408 字节**，SHA `04c1b942a92882602686c9faa0cedcb011ca621a486147e0eb9278916c578721`；输入 **9,409 字节**，SHA `266fa5b56516410712395796f197a2e33ad1b1e16ede45de14b872f208007d77`。两者实测不相等，9 个统计叶值改变：两个后期平均战长、boss 阶段、重击、两个经济均值、三个品质计数。新规则可以改变战斗长度与后续结果，完成/死亡门禁不要求旧 stdout 逐字相同。差异原值见 [current-gates-summary.json](evidence/round22/verification/current/current-gates-summary.json)。

两版原生 TAP.gz 均为完整原始输出。当前 90 份模块 stdout 的恢复 SHA 与摘要逐份匹配，90 个模块 stderr 均为空。npm 唯一 stderr 为输入已有的 http-proxy 环境提示，原文保留。

## 3. 原固定 4×400：当前 INCOMPLETE

两版使用原 `death-recovery-armor-v2`、同四种子、同脚本和预注册。每种子 **160,000 次决策**，死亡数 **大于 20 时停止**，支出 0；自然天赋全投 power、安全事件，仅在观察到自然失败后按原十二次压力启发式比较防具，最小比例改善 0.05。没有换种子、延长预算、修改策略阈值或停止条件。

| seed | 输入完成层/投掷/死亡/换甲 | 当前完成层 | 当前终态层 | 当前投掷 | 死亡 | 换甲 | 结果 |
|---:|---|---:|---:|---:|---:|---:|---|
| 7919 | 400/5422/0/0 | 39 | 40 | 938 | 21 | 1 | DEATH_RETRY_LIMIT |
| 15838 | 400/5034/0/0 | 400 | 400 | 4994 | 0 | 0 | COMPLETED |
| 23757 | 400/5612/2/2 | 400 | 400 | 5696 | 2 | 2 | COMPLETED |
| 31676 | 400/5528/0/0 | 84 | 85 | 1666 | 21 | 1 | DEATH_RETRY_LIMIT |
| 合计 | 1600/21596/2/2 | **923** | — | **13294** | **44** | **4** | **2/4；exit 2** |

当前 42 次防具决策、4 次合法换甲、全部 0 支出；19 次完整 codec 往返、686 次合法天赋分配、64 次全量/投影检查、256 次 compact/full 比较均通过。输入为 11 次 codec、1086 次分配、64 次投影和 256 次比较。校验点不是额外自然旅程。

当前报告状态 `MEASURED_WITH_INCOMPLETE_POLICY_SAMPLES`。7919 在第 40 层无名裂隙主、31676 在第 85 层灰烬铸王达到 21 次死亡，两终态敌人均为 combatRules 4。终态敌人身份本身不能证明此前轨迹分岔原因。四种子固定策略只提供有限离线可达性样本，不能换算成人类胜率或全种子平衡保证。

两版完整最终报告、**7 份输入 + 15 份当前**原始存档以 gzip 保留，无裁剪。当前 15 份存档又经只读 decode，原始 envelope、归一化完整 state SHA 和报告 metadata 全匹配。这 15 份证据检查与运行中的 19 次 codec 分别记录。

- [输入完整长报告](evidence/round22/verification/baseline/natural-armor-v2/report.json.gz)
- [当前完整长报告](evidence/round22/verification/current/natural-armor-v2/report.json.gz)
- [7919 失败终态](evidence/round22/verification/current/natural-armor-v2/seed-7919-incomplete-terminal.save.json.gz)
- [31676 失败终态](evidence/round22/verification/current/natural-armor-v2/seed-31676-incomplete-terminal.save.json.gz)
- [15 份存档证据检查](evidence/round22/verification/current/save-evidence-audit.json)

### 两份原样失败终态的合法恢复（不改正式2/4）

原装备各6次retry对照均失败。各从同一原始终态合法装备已有i182/i428护甲，再retry和roll，分别20/21掷首战胜，0额外死/0支出、胜后HP2480/6204。182个完整真实转换和原始codec与旧规则4引擎一致，所有输入证据及源码不变。只证明两保存可合法解困，不认证所有种子或400层后续；完整原始全态trace和失败对照见 [恢复摘要](evidence/round22/gameplay/long-run-triage/summary.json)。

## 4. 无损证据包与保留的 QA 修正

[verification/README](evidence/round22/verification/README.md) 说明目录与恢复方法。[evidence-map.json](evidence/round22/verification/evidence-map.json) 保留原路径/bytes/SHA → 包内路径/bytes/SHA；70 份复制证据均恢复后与来源逐字一致。大于 100,000 字节文本和所有原始存档压缩，原生 TAP.gz 原样复制。外部绝对路径 helper 不进游戏包，项目原脚本可重跑实际检查。

两个 report.json.partial.json 都是同一运行的检查点，其四个 journey 所有字段与对应完整最终报告精确相等，不是独立新测试。映射保留原 bytes/SHA、metadata、相等校验及最终报告去向，成品只存完整最终报告。

基线首次后处理错误地把 encodeSave 外层 envelope 当作 state，并归一化不存在的外层 runId，得到 7 对 false。**错误摘要和修正说明保留于 baseline/development/**。修正后使用未改变的 storage.js 解码并验证原始 envelope，只归一化真实 state 顶层 runId，其余全部字段完整比较，7 对全相等。分析错误没有改写游戏命令的真实退出状态，也不增加游戏测试通过数。

失败证据、截图和夹具未删除。16 份历史 archive manifest 的无损压缩映射与恢复核对在 [round22/package](evidence/round22/package/README.md)，主要减少展开体积，不能宣称 ZIP 下载量有同等减少。

## 5. 浏览器与性能独立口径

根流程确认最终浏览器功能检查 **11 作业、57 场景、全部退出 0，源码哈希未变**；原始记录和截图在 [round22/browser](evidence/round22/browser/)。这些场景不与 840 个原生案例相加，功能通过也不等于性能提高。

正式性能窗口在离线门禁启动前已结束，并在测量时与其他测试/模拟隔离。环境、帧窗与写档口径以 [PERFORMANCE](PERFORMANCE.md) 和原报告为准。Node 模拟不替代实体 GPU/手机、真实听音、系统输入法或物理断电验证；本文不新增这些尚未执行的覆盖声明。

## 6. 全新解压的实际门禁与最终重封装

实际来源是本轮第一完整实体候选（35,539,101字节、3,208文件），由未修改的verify-package.py完整CRC、安全路径、清单及真实重解压通过。随后只从该新目录运行163模块check、完整npm test（90模块、实际840/840项）；fail/cancel/skip/todo均0。这一次npm test实际输出840项；此前相同源码的独立原生明细运行也为840/840，两个命令分别记账，不将一次输出冒称两次执行。

65个实际公开资源响应与新解压文件逐字/SHA匹配，JS相对import和CSS URL全部解析，10个私有/越界路径拒绝。实际serve由新解压目录启动，确认该进程自身的ready后才请求，结束和错误路径均清理。301个运行资源、全部脚本/测试/夹具、启动入口及3份关键历史材料前后SHA相同。

全部执行命令、耗时、stdout/stderr、完整HTTP响应哈希和原始候选身份见 [fresh-source-gate](evidence/round22/package/fresh-source-gate/PACKAGE-MAP.json)。外部执行器准备期曾发现完整字符串排序口径差异，并在完整测试前遇到默认沙箱loopback权限阻断；保留于development/final-gate-preparation，均未执行完整npm test。获自动审批允许后只执行了这一次新解压完整测试。外部归档器最初误将默认输出粒度硬编码为90包装项，遇到实际840项全通过后触发计数断言；原始诊断、计数修正与随后HTTP接续均保留在fresh-source-gate/development，未重跑完整测试，也未修改游戏来绕过权限。

回填交接文档与压缩原始日志后，正式ZIP重新生成清单、CRC和空目录提取，并必须把全部301行执行文件与刚刚通过的完整门禁逐字绑定。此阶段不冒称又运行一次完整测试；最终HTTP另从正式ZIP的新解压目录实际启动随包serve复核。ZIP标准注释记录真实大小、文件数和交付门禁来源，ZIP SHA只放最终答复，避免自引用。只有这些最终绑定和资源复核通过才交付。

项目根目录重跑：

```bash
npm run check
npm test
python scripts/verify-test-cases.py --output /tmp/round22-native --workers 4
node scripts/simulate.mjs 1000
node scripts/strategy-round18.mjs --source . --output /tmp/round22-policy/report.json
```

最后一条内置原四种子、400 层目标和停止规则，不完整退出 2，应保留报告及存档。基线须在上传 5.21.0 的重新解压根目录执行，不能用当前源码冒充输入复跑。浏览器驱动的依赖与参数按原报告，游戏运行不依赖测试用浏览器工具。
