# 下一轮起跑路线 · 输入 v5.22.0 / Round22

仅上传本轮完整 ZIP 和同一份云端迭代任务书即可开始 Round23。无需前序聊天、补丁链、外部仓库或用户本地代理。先验 ZIP 的真实字节与 SHA，再从 STATE、LATEST_REPORT、VERIFY、BUG_LEDGER 和 evidence/round22/README 开始。新任务书若覆盖本页，遵循用户最新约束。

## 优先五项

1. **P2：恢复策略的构筑盲区与真实预算价值。** 原 death-recovery-armor-v2 固定7919/15838/23757/31676、各400层，本轮只有2条完成。先复现保留的40/85层失败，不换种子、不放宽21死/160000决策停止。原模型遗漏同点护盾等收益；从实际装备与合法行动证据定义下一个独立策略，保留旧策略作为未通过对照。若涉及付费，预注册总预算、单次预算、停止规则、净消费与阶段覆盖，不把零消费自动结果当人类难度。
2. **P2：软件长帧与真实GPU的负载归因。** 本轮16主窗＋14品质窗，每格1次；当前最大10.3483秒，8主格中7格max更差、三窗FX未捕获。先分开JS long task、rAF调度和绘制，再选一个可验证的轻改动。实际硬件可用时才做物理4K结论；无硬件就诚实保留未测。
3. **P2：万件背包首次打开与保存尾部。** 纯筛选/翻页已有12对真浏览器收益，不能移植为打开或保存结论。继续保留完整新HTML和expected，先区分模板、DOM替换、编码、主镜像setItem和回帧；不要重引入 Round16 被回滚的跨状态排序缓存或 Round21 被撤回的 raw expected/公共对象索引复用。
4. **P3：其余8对等价深层变体。** 本轮只让偶刻监军、离序执灯者产生真实差异。先做小范围机制、可达性、骰数条件和人类理解设计，再扩展；保持已保存旧pending规则。新增战斗版本必须使用已知可验证字段，不占用历史未知字段；不得为了“不同”硬拉高死亡率。
5. **P3：新规则提示的人类理解与可达性。** 当前仅自动键盘、六种视口和源码字形检查；实际读屏、中文输入法、听音与玩家理解未测。验证“当前一掷/下一掷”“同点/全异”“存活反击后重筑”能否被正确理解，再做小幅文案或排版改进。

## 必须保留的回归边界

- 手动最多六骰、六房主循环、八品质和30/50/80/140门槛、单金币、五装备槽。
- schema5、旧ID/未知字段、V1–4迁移、完整expected、主镜像和Web Locks；正常交易与同步继续全量render。
- 同局跨标签保存后，未提交搜索草稿和选区/方向均保留；清空、修剪、换局、弹窗不能套旧选区。
- `inventoryOnly` 仅用于同一已显示状态对象的背包纯视图操作，完整HTML相等才能保留卡片；dirty input/select要同步，结构异常回退。
- 旧 `combatRules` 缺失/2/4 与未知 `deepVariantRules` 任意合法值保持原语义；新5仅用于两种符合配置的变体。重试同一战斗不升级旧pending。当前实际含combatRules:5敌人状态的存档不支持旧v5.21程序读取。
- 启明星首次有资格触发，而非本场绝对首次暴击；已获得nextLuck与本场触发机会分开；历史归档中的OPEN_SEMANTIC已被Round21说明澄清。

## 启动与复测

解压进入 `Dice-Abyss`，有 Node.js 后直接 `npm start`；无需安装第三方运行包。默认地址由 serve 输出，启动脚本、Windows辅助入口与字体全部随包保留。不要双击HTML后把模块安全限制当游戏故障。

```sh
npm run check
npm test
python3 scripts/verify-test-cases.py --output /tmp/dice-round23-native --workers 4
node scripts/simulate.mjs 1000
node scripts/strategy-round18.mjs --source . --output /tmp/dice-round23-strategy/report.json
python3 scripts/verify-package.py --help
```

原生细项与策略的本轮**真实完整命令**以 [VERIFY.md](VERIFY.md) 和 evidence/round22/verification/*/*.run.json 为准；不要照抄未经确认的参数名。最终默认90模块，独立原生840案例；长策略明确exit2未完成，不能用完成的两种子替换它。

浏览器脚本包括 `qa-round22-browser.mjs`、`qa-inventory-view-latency-round22.mjs`、原有 core/inventory-navigation/forge/fusion/talents/environment/iteration/performance/storage-latency 驱动。Playwright仅为可选QA工具，不是游戏运行依赖；在已有浏览器环境指定 PLAYWRIGHT_MODULE 与 CHROMIUM_PATH。正式性能应固定输入并与CPU密集测试错开，保留热身、全部慢样本和源码SHA。自然模拟与人工构造调试档分开计数。

## 包体纪律与证据

仅一个完整 ZIP，真实大小严格 `<50,000,000` 字节，目标≤40,000,000。当前所有字体/许可、旧测试和重要复现材料保留。16个历史大清单已无损gzip，按 evidence/round22/package/historical-manifests.json 与 `scripts/restore-historical-manifests.py` 可还原；这主要减少解压文件体积，不代表ZIP下载减掉2.4MB。

本轮原始大报告与完整状态使用gzip保存，文件内容不裁剪；开发失败、撤回候选与最终记录明确分离。输入Runtime差异可用 evidence/round22/baseline/restore-runtime.py 复原到空的外部目录；它恢复旧运行文件，**不宣称重建旧ZIP**。下一轮正常启动、修改、测试不需要复原旧版。

本轮没有更换渲染器、引入新位图/音频/字体、修改概率/价目/奖池、新增第二货币/账号/联网服务，也没有完成物理设备或长期付费策略验收。
