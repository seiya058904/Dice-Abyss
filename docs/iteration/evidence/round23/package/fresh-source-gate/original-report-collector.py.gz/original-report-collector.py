#!/usr/bin/env python3
"""Execute the authorized release gates against an already fresh extraction."""
from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, re, subprocess, time

p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=a.source.resolve();out=a.output.resolve()
assert source not in out.parents and not out.exists()
out.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
    rows=[]
    for f in sorted(source.rglob('*')):
        if not f.is_file():continue
        rel=f.relative_to(source).as_posix()
        if rel.startswith(('src/','scripts/','tests/')) or rel in ('index.html','package.json','README.md','favicon.svg') or f.suffix in ('.js','.mjs','.py'):
            b=f.read_bytes();rows.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
    return rows
before=identity();(out/'execution-identity-before.json').write_text(json.dumps(before,indent=2)+'\n')
gate={'status':'RUNNING','source':str(source),'startedUTC':now(),'identityScope':'All src/scripts/tests files, index/package/README/favicon, and all .js/.mjs/.py anywhere in project, including archived QA helpers. Evidence/report-only final repacking must not alter any of these bytes.','executionIdentityFiles':len(before),'commands':[]}
started=time.monotonic()
commands=[('check',['npm','run','check']),('test',['npm','test']),('http',['node','scripts/smoke-http.mjs','--output',str(out/'http-report.json')])]
for name,cmd in commands:
    entry={'name':name,'command':cmd,'cwd':str(source),'startedUTC':now()};print(json.dumps(entry),flush=True)
    t=time.monotonic();run=subprocess.run(cmd,cwd=source,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    entry.update(finishedUTC=now(),seconds=round(time.monotonic()-t,4),exitCode=run.returncode)
    for label,raw in [('stdout',run.stdout),('stderr',run.stderr)]:
        payload=gzip.compress(raw,compresslevel=9,mtime=0);(out/(name+'.'+label+'.log.gz')).write_bytes(payload)
        entry[label]={'bytes':len(raw),'sha256':sha(raw),'gzipBytes':len(payload),'gzipSha256':sha(payload)}
    if name=='test':
        body=run.stdout.decode('utf8',errors='replace');entry['tapSummary']={k:int(re.findall(r'^(?:#|ℹ)\s+'+k+r' (\d+)\s*$',body,re.M)[-1]) for k in ('tests','suites','pass','fail','cancelled','skipped','todo') if re.findall(r'^(?:#|ℹ)\s+'+k+r' (\d+)\s*$',body,re.M)}
    (out/(name+'.run.json')).write_text(json.dumps(entry,ensure_ascii=False,indent=2)+'\n');gate['commands'].append(entry);print(json.dumps(entry),flush=True)
    if run.returncode!=0:gate['status']='FAILED';break
after=identity();(out/'execution-identity-after.json').write_text(json.dumps(after,indent=2)+'\n')
gate.update(finishedUTC=now(),seconds=round(time.monotonic()-started,4),executionIdentityStable=before==after)
if len(gate['commands'])==3 and all(r['exitCode']==0 for r in gate['commands']) and before==after:
    http=json.loads((out/'http-report.json').read_text());assert http['allPassed'] and http['files']==65
    summary=gate['commands'][1]['tapSummary'];assert summary['pass']==92 and summary['fail']==summary['cancelled']==summary['skipped']==summary['todo']==0
    gate['status']='PASSED_FULL_FRESH_SOURCE_GATE';gate['freshSyntaxModules']=sum(1 for folder in ['src','scripts'] for f in (source/folder).iterdir() if f.suffix in ('.js','.mjs'));gate['freshDefaultModules']=summary['tests'];gate['httpAssets']=http['files']
else:gate['status']='FAILED'
(out/'final-gate.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':gate['status'],'seconds':gate['seconds'],'executionIdentityFiles':len(before)}),flush=True)
raise SystemExit(0 if gate['status']=='PASSED_FULL_FRESH_SOURCE_GATE' else 1)
