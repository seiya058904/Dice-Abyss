// Round22 native browser checks. Tester supplies Playwright/Chromium; no runtime dependency.
// --source=/absolute/project --url=http://127.0.0.1:4221/ --output=/tmp/fresh-dir
// --suite=inventory|deep|layout|performance --expect=baseline|current
// Connected Browser and cloud CUA both returned ERR_CONNECTION_REFUSED for this
// workspace's loopback server. The task explicitly permits local Playwright QA.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const args=Object.fromEntries(process.argv.slice(2).map(arg=>{const at=arg.indexOf('=');return [arg.slice(2,at),arg.slice(at+1)];}));
const root=path.resolve(args.source),url=args.url,output=path.resolve(args.output),suite=args.suite||'inventory',baseline=args.expect==='baseline';
assert(['127.0.0.1','localhost'].includes(new URL(url).hostname));
assert(!output.startsWith(root+path.sep),'Evidence stays outside source');
await fs.mkdir(output,{recursive:true});
await assert.rejects(fs.access(path.join(output,'report.json')),'Use a new attempt directory');
const [E,S]=await Promise.all(['engine','storage'].map(file=>import(pathToFileURL(path.join(root,'src',file+'.js')))));
const {chromium}=createRequire(import.meta.url)(process.env.PLAYWRIGHT_MODULE||'playwright');
const sha=value=>createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value)).digest('hex');
const sourceFiles=['index.html','src/app.js','src/views.js','src/engine.js','src/storage.js','src/inventory-dom.js','src/deep-rules.js','src/deep-content.js','src/encounter-tactics.js'];
const identity=async()=>Object.fromEntries(await Promise.all(sourceFiles.map(async p=>[p,sha(await fs.readFile(path.join(root,p)))])));
const report={started:new Date().toISOString(),suite,expected:baseline?'baseline':'current',url,sourceBefore:await identity(),scriptSha256:sha(await fs.readFile(fileURLToPath(import.meta.url))),cases:[],errors:[],notes:[
 'All contexts and saves are disposable. Fixture preparation uses the real validator and codec. No private save or external server is touched.',
 'Inputs use native pointer/keyboard/select controls and real localStorage/Web Locks. Only initial test fixtures are installed programmatically.',
 'Synthetic fixtures are not natural gameplay evidence. Full save equality compares every field, including RNG, revision, unknown fields and pending rewards.',
 'Functional checks use low effects and reduced motion. Performance runs, if selected, have their separately recorded protocol; none certify physical Windows or hardware GPU performance.'
]};
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
report.browser=browser.version();
let row;
const check=(value,label,detail)=>{row.checks.push({label,passed:!!value,...(detail===undefined?{}:{detail})});assert(value,label);};
const eq=(actual,expected,label)=>{row.checks.push({label,passed:false,actualSha256:sha(actual),expectedSha256:sha(expected)});assert.deepEqual(actual,expected,label);row.checks.at(-1).passed=true;};
const button=(p,a)=>p.locator(`[data-action="${a}"]`);
const raw=p=>p.evaluate(k=>localStorage.getItem(k),S.SAVE_KEY);
const saved=async p=>S.decodeSave(await raw(p));
const idle=p=>p.waitForFunction(()=>!document.querySelector('.room-panel')?.classList.contains('busy')&&!document.querySelector('#current-room')?.classList.contains('busy'));
const waitState=(p,s)=>p.waitForFunction(({key,expected})=>localStorage.getItem(key)===expected,{key:S.SAVE_KEY,expected:S.encodeSave(s)});
async function exact(p,state,label){eq(await saved(p),state,label);eq(await p.evaluate(k=>localStorage.getItem(k),S.BACKUP_KEY),await raw(p),label+' mirror');}
async function install(p,state,{effects='low',scale=1}={}){
 assert(S.validateSave(state));assert.deepEqual(S.decodeSave(S.encodeSave(state)),state);
 await p.goto(url);await p.evaluate(({raw,keys,effects,scale})=>{localStorage.clear();localStorage.setItem(keys[0],raw);localStorage.setItem(keys[1],raw);localStorage.setItem(keys[2],JSON.stringify({sound:false,effects,scale}));},{raw:S.encodeSave(state),keys:[S.SAVE_KEY,S.BACKUP_KEY,S.SETTINGS_KEY],effects,scale});
 await p.reload();await button(p,'continue').click();await p.evaluate(()=>document.fonts.ready);await idle(p);
}
async function shot(p,name){await p.screenshot({path:path.join(output,name+'.jpg'),type:'jpeg',quality:76});row.screenshots??=[];row.screenshots.push(name+'.jpg');}
async function run(name,fn,viewport={width:1366,height:768}){
 row={name,status:'RUNNING',checks:[],viewport};report.cases.push(row);
 const context=await browser.newContext({viewport,deviceScaleFactor:1,reducedMotion:'reduce'});
 await context.route('**/*',r=>r.request().url().startsWith(new URL(url).origin+'/')?r.continue():r.abort());
 const page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',e=>report.errors.push(String(e)));
 try{await fn({context,page});row.status='PASS';}catch(e){row.status='FAIL';row.error=String(e);row.stack=e.stack;await shot(page,'FAIL-'+name).catch(()=>{});}
 finally{await context.close();await fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(name+': '+row.status);}
}
function inventoryFixture(count=145){const s=E.newGame(22031);s.runId='round22-inventory-22031';s.round22Unknown={preserve:['all','fields']};while(s.player.items.length<count)s.player.items.push(E.makeItem(s,['weapon','armor','relic'][s.nextId%3],s.nextId%3));assert(S.validateSave(s));return s;}
const inventory=p=>p.locator('.main-nav [data-action="inventory"]').click();
const selection=p=>p.locator('#inventory-search').evaluate(n=>({value:n.value,start:n.selectionStart,end:n.selectionEnd,direction:n.selectionDirection,focused:document.activeElement===n}));
async function selectDraft(p){const input=p.locator('#inventory-search');await input.fill('甲乙丙丁戊己');await input.press('Home');await input.press('ArrowRight');await input.press('ArrowRight');await input.press('Shift+ArrowRight');await input.press('Shift+ArrowRight');}

try{
 if(suite==='inventory'){
  await run('same-run-native-storage-preserves-draft-selection',async({context,page})=>{
   const s=inventoryFixture();await install(page,s);await inventory(page);
   const peer=await context.newPage();peer.on('pageerror',e=>report.errors.push(String(e)));await peer.goto(url);await button(peer,'continue').click();await inventory(peer);
   await selectDraft(page);const before=await selection(page);eq([before.start,before.end],[2,4],'native keyboard creates middle selection');
   const lock=peer.locator('.inventory-list [data-action="lock"]').first(),id=await lock.getAttribute('data-id');
   const expected=E.transition(s,{type:'lock',id});await lock.click();await waitState(page,expected);
   await page.locator('.toast').filter({hasText:/另一窗口|镜像/}).waitFor({state:'visible'});
   const after=await selection(page);row.before=before;row.after=after;
   eq(after.value,before.value,'same-run unsubmitted draft survives');check(after.focused,'focus stays in search');
   if(baseline){check(after.start!==before.start||after.end!==before.end,'input version reproduces selection loss',{before,after});row.result='REPRODUCED_PRODUCT_BUG';}
   else eq(after,before,'same-run storage update preserves exact selection and direction');
   await exact(page,expected,'peer lock remains one complete engine transition');
   await page.locator('#inventory-search').press('x');const edited=await selection(page);row.nextTypedValue=edited.value;
   if(!baseline)eq(edited.value,'甲乙x戊己','typing replaces the intended selection after synchronization');
   await shot(page,'same-run-caret');
  });
  await run('pure-inventory-actions-keep-state-and-correct-results',async({page})=>{
   const s=inventoryFixture(300);await install(page,s);await inventory(page);
   await page.evaluate(()=>{window.__round22Shell={top:document.querySelector('.topbar'),left:document.querySelector('.left-rail'),right:document.querySelector('.right-rail'),bottom:document.querySelector('.bottomline')};});
   const controls=await page.locator('.inventory-screen [data-action]').evaluateAll(ns=>ns.slice(0,12).map(n=>({...n.dataset,text:n.textContent.trim()})));row.controls=controls;
   const slots=page.locator('.inventory-screen [data-action="inventory-filter"][data-slot="weapon"]');
   await slots.click();await page.locator('.inventory-list').waitFor();
   const slotValues=await page.locator('.inventory-list [data-action="lock"]').evaluateAll(ns=>ns.map(n=>n.dataset.id));
   check(slotValues.length>0&&slotValues.every(id=>s.player.items.find(i=>i.id===id)?.slot==='weapon'),'weapon filter shows only actual weapons');
   await page.locator('#inventory-sort').selectOption('level');
   await page.locator('#inventory-search').fill(s.player.items.find(i=>i.slot==='weapon').name);
   await page.locator('#inventory-search').press('Enter');
   const ids=await page.locator('.inventory-list [data-action="lock"]').evaluateAll(ns=>ns.map(n=>n.dataset.id));
   check(ids.length>0,'submitted search has matching items');
   const live=await selection(page);check(live.focused,'search submission keeps keyboard focus');
   const same=await page.evaluate(()=>Object.fromEntries(Object.entries(window.__round22Shell).map(([key,node])=>[key,node===document.querySelector({top:'.topbar',left:'.left-rail',right:'.right-rail',bottom:'.bottomline'}[key])])));row.shellIdentity=same;
   if(baseline)check(Object.values(same).some(x=>!x),'input rebuilds shell on pure filter');else check(Object.values(same).every(Boolean),'current keeps all outer shell nodes during pure view changes');
   await exact(page,s,'view-only actions never alter save or RNG');await shot(page,'inventory-results');
  });
 }
 else throw Error('Unimplemented suite '+suite);
}finally{
 report.finished=new Date().toISOString();report.sourceAfter=await identity();report.sourceUnchanged=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);
 report.checks=report.cases.reduce((n,r)=>n+r.checks.length,0);report.failed=report.cases.filter(r=>r.status!=='PASS').length;
 await fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));await browser.close();
}
console.log(JSON.stringify({cases:report.cases.length,checks:report.checks,failed:report.failed,errors:report.errors,sourceUnchanged:report.sourceUnchanged}));
if(report.failed||report.errors.length)process.exitCode=1;
