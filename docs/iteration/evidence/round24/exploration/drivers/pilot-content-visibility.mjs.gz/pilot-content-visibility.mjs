import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import * as E from '../baseline/Dice-Abyss/src/engine.js';
import * as S from '../baseline/Dice-Abyss/src/storage.js';
const {chromium}=createRequire(import.meta.url)(process.env.PLAYWRIGHT_MODULE);
const out=new URL('./css-pilot/',import.meta.url);await fs.mkdir(out,{recursive:true});
const fixture=E.newGame(27017);fixture.runId='round24-css-pilot-27017';fixture.floor=200;fixture.player.level=100;fixture.player.gold=1000000;fixture.player.hp=E.stats(fixture).maxHp;
while(fixture.player.items.length<10000)fixture.player.items.push(E.makeItem(fixture,undefined,fixture.nextId%8));
assert(S.validateSave(fixture));const raw=S.encodeSave(fixture);
const css='.inventory-list > .item-card { content-visibility:auto; contain-intrinsic-block-size:auto 24rem; }';
const report={status:'RUNNING',protocol:{kind:'Exploratory CSS-only A/B on immutable baseline, not a release benchmark',fixtureSha256:createHash('sha256').update(raw).digest('hex'),items:10000,css,viewport:{width:1920,height:1080},pairs:6,warmupPairs:1,quantile:'sorted floor((n-1)*p)',backend:'ANGLE SwiftShader; headless Linux; no physical GPU claim'},runs:[],errors:[]};
const save=()=>fs.writeFile(new URL('report.json',out),JSON.stringify(report,null,2));
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader']});report.browser=browser.version();
try{
for(let pair=0;pair<=6;pair++)for(const cv of pair%2?[true,false]:[false,true]){
 const context=await browser.newContext({viewport:report.protocol.viewport,reducedMotion:'reduce',deviceScaleFactor:1});
 try{
  const page=await context.newPage();page.on('pageerror',e=>report.errors.push(String(e)));await page.goto('http://127.0.0.1:4194');
  await page.evaluate(({raw,keys})=>{localStorage.setItem(keys.main,raw);localStorage.setItem(keys.mirror,raw);localStorage.setItem(keys.settings,JSON.stringify({sound:false,effects:'low',scale:1}));},{raw,keys:{main:S.SAVE_KEY,mirror:S.BACKUP_KEY,settings:S.SETTINGS_KEY}});
  await page.reload();await page.locator('[data-action="continue"]').click();await page.evaluate(()=>document.fonts.ready);
  if(cv)await page.addStyleTag({content:css});
  const cdp=await context.newCDPSession(page);await cdp.send('Performance.enable');
  const metric=async()=>Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map(x=>[x.name,x.value]));
  for(const [action,selector] of [['open','.main-nav [data-action="inventory"]'],['filter','[data-action="filter"][data-slot="weapon"]'],['page','.inventory-pagination [data-action="inventory-page"][data-page="1"]']]){
   await page.locator(selector).click({trial:true});
   await page.evaluate(selector=>{window.__measure=new Promise(resolve=>{const target=document.querySelector(selector);target.addEventListener('click',()=>{const t=performance.now();requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(performance.now()-t)));},{capture:true,once:true});});},selector);
   const before=await metric();await page.locator(selector).click();const elapsed=await page.evaluate(()=>window.__measure);const after=await metric();
   const geometry=await page.evaluate(()=>{const list=document.querySelector('.inventory-list'),cards=[...list.children];return {count:cards.length,scrollHeight:list.scrollHeight,clientHeight:list.clientHeight,cardHeights:cards.map(c=>c.getBoundingClientRect().height),omitted:cards.filter(c=>!c.querySelector('h3')?.checkVisibility({contentVisibilityAuto:true})).length};});
   const row={pair,phase:pair?'measured':'warmup',cv,action,elapsed,metrics:Object.fromEntries(['LayoutDuration','RecalcStyleDuration','ScriptDuration','TaskDuration'].map(k=>[k,(after[k]-before[k])*1000])),geometry};report.runs.push(row);await save();
  }
  if(pair===6){
   await page.screenshot({path:new URL(cv?'after-top.png':'before-top.png',out).pathname});
   const jumps=[];
   for(const index of [12,30,59,30,0]){const card=page.locator('.inventory-list > .item-card').nth(index);await card.scrollIntoViewIfNeeded();await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));jumps.push(await card.evaluate((el,index)=>({index,top:el.getBoundingClientRect().top,height:el.getBoundingClientRect().height,scrollTop:el.parentElement.scrollTop,scrollHeight:el.parentElement.scrollHeight,visible:el.querySelector('h3').checkVisibility({contentVisibilityAuto:true})}),index));}
   report.scrollChecks??=[];report.scrollChecks.push({cv,jumps});
   assert(jumps.every(j=>j.visible));assert.equal(await page.evaluate(key=>localStorage.getItem(key),S.SAVE_KEY),raw);
  }
  console.log(JSON.stringify({pair,cv,rows:report.runs.slice(-3).map(r=>({action:r.action,elapsed:r.elapsed,layout:r.metrics.LayoutDuration,omitted:r.geometry.omitted}))}));
 }finally{await context.close();}
}
report.aggregate={};
const summarize=xs=>{const s=xs.toSorted((a,b)=>a-b);return {n:s.length,p50:s[Math.floor((s.length-1)*.5)],p95:s[Math.floor((s.length-1)*.95)],max:s.at(-1)};};
for(const action of ['open','filter','page']){report.aggregate[action]={};for(const cv of [false,true]){const rows=report.runs.filter(r=>r.pair&&r.action===action&&r.cv===cv);report.aggregate[action][cv?'candidate':'baseline']={latency:summarize(rows.map(r=>r.elapsed)),layout:summarize(rows.map(r=>r.metrics.LayoutDuration)),style:summarize(rows.map(r=>r.metrics.RecalcStyleDuration)),script:summarize(rows.map(r=>r.metrics.ScriptDuration))};}}
report.status='COMPLETED';
}catch(e){report.status='FAILED';report.failure={message:String(e),stack:e.stack};process.exitCode=1;}
finally{await save();await browser.close();console.log(JSON.stringify({status:report.status,aggregate:report.aggregate,failure:report.failure}));}
