from pathlib import Path
import subprocess,os,json

root=Path('/workspace/scratch/173d072e7238/work/Dice-Abyss')
audit=Path('/workspace/scratch/173d072e7238/audit')
env=os.environ.copy()
env['PLAYWRIGHT_MODULE']='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.js'
env['CHROMIUM_PATH']='/tmp/dice-chromium/chrome-headless-shell-linux64/chrome-headless-shell'
url='http://127.0.0.1:4195/'
jobs=[
 ('current-core','scripts/qa-core-browser.mjs',[]),
 ('current-inventory-search','scripts/qa-inventory-search-round15.mjs',[]),
 ('current-services','scripts/qa-round11-browser.mjs',['--case=merchant-forge-event-choices']),
 ('current-fusion','scripts/qa-round11-browser.mjs',['--case=fusion-selection-confirmation']),
 ('current-forge','scripts/qa-forge-preview-browser.mjs',['--case=five-slots-exact-transactions']),
 ('current-talents','scripts/qa-talents-browser.mjs',['--cases=quantity-preview-and-exact-commit']),
 ('current-lifecycle','scripts/qa-renderer-lifecycle.mjs',['--baseline-url=http://127.0.0.1:4194/']),
]
results=[]
for name,script,extra in jobs:
    localenv=env.copy()
    if name=='current-lifecycle':localenv['PLAYWRIGHT_MODULE']=env['PLAYWRIGHT_MODULE'].replace('/index.js','/index.mjs')
    cmd=['python3',str(audit/'run-recorded.py'),'--cwd',str(root),'--output',str(audit/'executions'/name),'--','node',script,'--url='+url,'--output='+str(audit/name),*extra]
    print('REGRESSION START',name,flush=True)
    p=subprocess.run(cmd,env=localenv)
    results.append({'name':name,'exitCode':p.returncode})
(audit/'browser-regressions.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(1 if any(r['exitCode'] for r in results) else 0)
