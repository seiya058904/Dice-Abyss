from pathlib import Path
import argparse,subprocess,time,datetime,json,hashlib,threading,sys

parser=argparse.ArgumentParser()
parser.add_argument('--cwd',required=True)
parser.add_argument('--output',required=True)
parser.add_argument('command',nargs=argparse.REMAINDER)
args=parser.parse_args()
cmd=args.command[1:] if args.command and args.command[0]=='--' else args.command
assert cmd
out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
start=time.time()
p=subprocess.Popen(cmd,cwd=args.cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def pump(stream,name,destination):
    with (out/(name+'.log')).open('wb') as target:
        for line in iter(stream.readline,b''):
            target.write(line);target.flush()
            destination.buffer.write(line);destination.flush()
threads=[threading.Thread(target=pump,args=(p.stdout,'stdout',sys.stdout)),threading.Thread(target=pump,args=(p.stderr,'stderr',sys.stderr))]
for t in threads:t.start()
code=p.wait()
for t in threads:t.join()
row={'command':cmd,'cwd':args.cwd,'startedAtUTC':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),'seconds':time.time()-start,'exitCode':code}
for stream in ('stdout','stderr'):
    data=(out/(stream+'.log')).read_bytes();row[stream]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'run.json').write_text(json.dumps(row,indent=2)+'\n')
print('RECORDED',json.dumps(row),flush=True)
raise SystemExit(code)
