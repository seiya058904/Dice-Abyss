from pathlib import Path
import subprocess, json, time, datetime, hashlib

root = Path('/workspace/scratch/173d072e7238/work/Dice-Abyss')
out = Path('/workspace/scratch/173d072e7238/audit/current')
out.mkdir(parents=True, exist_ok=True)
jobs = [
    ('check', ['npm', 'run', 'check']),
    ('test', ['npm', 'test']),
    ('native', ['python3', 'scripts/verify-test-cases.py', '--output', str(out/'native'), '--workers', '4']),
    ('simulate', ['node', 'scripts/simulate.mjs', '1000']),
    ('font', ['python3', 'scripts/audit-offline-fonts.py', '--output', str(out/'fonts.json')]),
    ('http', ['node', 'scripts/smoke-http.mjs', '--output', str(out/'http.json')]),
]
rows = []
for name, cmd in jobs:
    assert not (out/(name+'.run.json')).exists(), 'Use a fresh report directory'
    start = time.time()
    print('START', name, datetime.datetime.now(datetime.timezone.utc).isoformat(), flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout, (out/(name+'.stderr.log')).open('wb') as stderr:
        result = subprocess.run(cmd, cwd=root, stdout=stdout, stderr=stderr)
    row = {'name':name, 'cmd':cmd, 'cwd':str(root), 'startedAtUTC':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(), 'seconds':time.time()-start, 'exitCode':result.returncode}
    for stream in ('stdout','stderr'):
        payload=(out/(name+'.'+stream+'.log')).read_bytes()
        row[stream]={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
    (out/(name+'.run.json')).write_text(json.dumps(row,indent=2)+'\n')
    rows.append(row)
    print('DONE', name, json.dumps(row), flush=True)
(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(1 if any(r['exitCode'] for r in rows) else 0)
