# Round23 · 实际验收记录

本报告对应上传v5.22.0和最终v5.23.0。**功能/兼容门槛通过；特效性能及严格RGBA仍有未通过项，单列如下。** 各执行命令、起止时间、退出码、完整日志及源码身份见 `evidence/round23/verification/` 与各证据目录。没有用历史轮次报告冒充本轮实测。

## 一、输入与当前源码

| 验证 | 本轮输入v5.22 | 当前v5.23 | 备注 |
| --- | --- | --- | --- |
| npm run check | PASS，5.332秒 | PASS，6.4486秒 | src/scripts原163/当前166个JS模块；不含测试模块 |
| 默认npm test | 90/90模块，81.99秒 | fresh ZIP 92模块/854案例，78.0589秒 | 最终fresh结果另见封包门槛，不重复计数 |
| 独立逐模块原生TAP | 90模块/840案例，85.1045秒 | 92模块/854案例，95.7804秒 | 两版fail/cancel/skip/todo全0；完整TAP无损gzip |
| 标准＋noShopping模拟 | 1000＋50，217.331秒 | 1000＋50，245.2336秒 | 全部10层完成、0死亡失败；墙钟不作速度指标 |
| 完整短模拟stdout | 9408字节 | 9408字节 | 完整字节相同，未归一化 |
| HTTP资源 | 65项，exit0，0.7998秒 | fresh ZIP 65项，0.7845秒 | 真实子服务器ready；逐字节、import/CSS URL/MIME和私有路径404 |

短模拟完整stdout共同SHA：`04c1b942a92882602686c9faa0cedcb011ca621a486147e0eb9278916c578721`。源码验收前后303文件相同；原90测试逐字保留，新2模块共14案例。check的既有npm http-proxy环境警告原样保留。输入原生TAP没有外层run/stdout/stderr包装，现有summary含起止/Node/计数，完整TAP保留；没有补造缺失记录。

新增案例覆盖batch单次stats、完整返回等价、引用独立、原位修改、遗物位与num双转换；终帧回调次序/DOM fallback/取消/hidden/deadline/真实effects+motion单次rest，以及既有生产骰面整数域和严格像素比较器。

## 二、固定4×400长期策略

原death-recovery-armor-v2、原种子7919/15838/23757/31676、400层目标与21死亡停止限制不变。两版都实际运行并保留exit2：各2/4完成、923层、13294掷、44死、42防御决策、4换甲、0花费。7919在40层21死、31676在85层21死；15838到400层0死，23757到400层2死。

独立对照4个完整journeys的所有嵌套字段、42个完整decision、48条已导出attemptOpenings、96条末尾roll记录一致。15对导出存档各自codec验证并逐字重编码，完整state仅runId按原协议归一后相同；4个finalStateSha/encounterTraceSha相同。未导出的全attempts数组只由原脚本哈希覆盖，未声称另行读取/重哈希原数组。原final/partial/save/log全保存，见 `evidence/round23/long-policy/`。

## 三、原生浏览器功能

真实Chromium155/Linux/SwiftShader、DPR1，本轮10个job均exit0；**45个结果单位：44case＋1forge group，其中current42、baseline3**；记录的runtime errors=0。明确计数检查336；其余观察不混加。浏览器使用隔离合成存档和明确的故障注入，不使用私人存档。

| job | 结果单位 | 明确检查 | 主要覆盖 |
| --- | ---: | ---: | --- |
| core | 6 | 43 | 新局、手动命运/战斗、开箱装备、刷新、主写失败、镜像警告、跨标签过期确认 |
| inventory | 2 | 13 | 搜索草稿/选区保持；纯视图不改完整存档/RNG |
| services | 2 | 21 | 商店买入装备、付费事件取消确认、随后战斗 |
| layout | 12 | 108 | 两种战术卡×四桌面/1100/390，键盘与按钮可达 |
| iteration | 6 | 单独观察 | 四桌面首屏、3次原生context恢复、旧v4镜像归档、拒绝无效导入 |
| environment | 3 | 单独观察 | about:blank返回续玩、reduced-motion、加载后离线操作再联网刷新 |
| lifecycle | 11（含baseline3） | 单独观察 | 延迟/缺失rAF、期限、skip/hidden、low/reduced、精确单次交易 |
| forge | 1 group | 101 | 五装备槽精确锻造/预算/刷新 |
| fusion | 1 | 30 | 材料保护、取消确认、右键锁定、滚动 |
| talents | 1 | 20 | 数量预览、精确提交/扣费 |

四桌面为1366×768、1920×1080、2560×1440、3840×2160；另1100×700@1.1、390×844。实际看过核心背包/宝箱、1366战斗、4K标题、context失去/恢复、full结算和390窄屏。原始大截图不全入包，浏览器索引保留SHA和取舍，实际保留2张原PNG；不转码改图。390截图是滚动到卡片时的位置，不能把视口外场景延续误判为新回归；脚本另检无横向溢出/手动可达。

3次WEBGL_lose_context/restoreContext真实事件和恢复后一次精确交易通过。hidden与rAF缺失为注入，不等于物理休眠；加载后离线不等于离线HTTP刷新。上述7主job源前后300文件不变；lifecycle已记录的52个HTTP响应逐项匹配对应版本，范围不扩成所有未记录模块。

## 四、字体与内容完整性

当前字体审计PASS：60源文件、1058汉字/21CJK标点、197CSS字体栈，没有所需字符缺失、坏栈或旁路。两个本地字体、许可证和其它字体材料逐字保留。历史修复trace输入未提供，NOT_AVAILABLE不冒充通过。全部旧fixture、90测试、旧scripts以及运行美术/音效/CSS保留；精确差异见package源保护清单。

## 五、性能与像素未通过项

CPU336记录、原生背包72正式＋6预热、保存24正式＋2预热、帧48主＋14品质窗6745间隔全部保留。统计、正负样本、环境、来源身份范围见PERFORMANCE。没有整体FPS、普遍交互改善或物理GPU认证。

strict RGBA final-attempt04为**FAILED**，7/12 fixed exact，基线自身恢复4像素差提前终止，current恢复/sourcesAfter未运行。92完整RGBA引用无损保留。功能恢复PASS不替代它；shader已恢复原文件。8/8帧cell当前worst-max更差，9full窗缺所需阶段，仍OPEN_RISK。

## 六、最终封包门槛

最终门槛在空目录安全解压后执行原脚本：CRC/路径与预算/全部manifest SHA，npm run check，完整npm test，65资源HTTP。已实际完成：fresh check 4.7653秒，完整npm test 78.0589秒（92/92模块），HTTP 0.7845秒（65资源）；从check启动至HTTP完成的命令窗口83.6243秒。386个执行文件前后逐字稳定。原始回执和完整日志在 `evidence/round23/package/fresh-source-gate/`。随后只回填报告重封包；最终ZIP在交付前再次安全解压并核对全部执行身份，不虚称第二遍完整测试。

### 汇总器口径纠正（没有重跑或重写原始日志）

上述新目录的check/test/HTTP三个子命令都exit0；本次原生node:test实际输出854通过案例。外层临时汇总器错把92模块数当作case数，因pass==92断言自身exit1。已从原始三个run JSON、完整stdout/stderr SHA、854/854原生计数、92个实际测试模块路径和386文件前后身份重新核对并生成完成回执。没有将该汇总器exit1改写成0，也没有为统计重跑测试；原汇总器代码、失败说明与所有子命令原件保存在fresh-source-gate，final-gate明确列出originalCollectorExitCode=1。此处是报告收集错误，不能称游戏测试失败，也不能隐藏为外层执行全绿。
