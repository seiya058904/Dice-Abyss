# Round24 起跑路线

唯一权威起点是本包v5.23.0 / Round23；配合同一任务书即可继续，不能拿公开旧分支或历史截图覆盖本包。先读STATE、LATEST_REPORT、PERFORMANCE、BUG_LEDGER、VERIFY，再读evidence/round23/README。原Round22顶层资料已逐字gzip归档在docs/iteration/evidence/round23/baseline/provided-reports；HISTORY保留时间线。

## 五个优先候选

1. **P2：特效长帧因果分段。** 本轮3对/cell的8/8 worst-max更差，但6/8不执行终帧改动；24对max14慢/10快，不能指定根因。先预注册同字节A/A复刻两个持留context，再做仅切换motion/effects的ablation；记录终帧提交时间、后台页面活动、合成/栅格等待及全部缺FX。A/A单独不能证明fix无回退。真实GPU在可用时独立测，不与SwiftShader混池。
2. **P2：万件首开与保存后的长尾。** CPU center已降10.20%，但首开max105.2→129.3ms、分页p50变慢、保存后等待p95变差。按构造/排序/模板/布局分段，保持完整DOM、原生click和全部慢对。不要复活Round16已撤回排序方案而只给Node单点；不绕过expected、Web Locks或主镜像。
3. **P2：修复严格像素诊断的归因缺口。** 相同renderer也有1级通道差；原baseline恢复失败，current恢复未执行。补实际linked shader、uniform/atlas、GL状态与DOM几何记录；不能靠提高容差/删透明RGB把失败涂绿。renderer原字节与92完整RGBA都在包内。
4. **P2：长期策略模型与有限预算。** 原4×400仍2/4，7919到40层、31676到85层死亡限制停止。先补pairWard等生存模型盲区，另行预注册预算/停止条件；保留原策略exit2及原终态。Round22合法换甲解困是历史实证，本轮未重跑恢复实验。
5. **P3：其余深层身份与规则理解。** 8对等价变体、三骰条件概率、构筑多样性和经济尚未系统认证。若改机制，须从旧pending兼容、自然可达性、文案真值和新RNG轨迹解释开始，不为了轮换主题机械扩表。

## 关键复测入口

从项目根目录运行（Node>=20，无需npm install）：

```sh
npm run check
npm test
node scripts/simulate.mjs 1000
python scripts/verify-test-cases.py --help
node scripts/smoke-http.mjs --output /absolute/external-qa/http.json
node scripts/strategy-round18.mjs --source /absolute/Dice-Abyss --output /absolute/external-qa/strategy.json
python scripts/verify-package.py /absolute/release.zip --extract /absolute/empty-destination --output /absolute/external-qa/package.json
```

原生浏览器驱动需环境提供Playwright和Chromium，这些是QA工具而不是游戏依赖；按各脚本--help/既有run.json传绝对外部输出目录。多数createRequire驱动用index.js，新renderer/lifecycle ESM驱动用index.mjs；已保留入口错误attempt01。性能驱动为audit-inventory-comparison-round23、qa-inventory-latency-round23、qa-storage-latency、qa-performance-round12；使用前读其protocol和参数，不直接套历史baseline预期。

## 不可回退

原90测试、fixture、旧脚本、字体和许可不能删除。保留dawnCrit已获幸运跨箱/刷新/多波，实际战斗消费与离层/重燃清除；schema5/keys/ID/未知字段、完整expected/Web Locks/主镜像/先验后归档；手动六骰、六房、八品质门槛和独立Lv/+N。

compareEquipmentBatch仅一次同步共享before，不能跨状态缓存、暴露可信上下文或复用可变结果。num保留两次Number转换、阈值、en-US普通路径。终帧保留onFrame→onRest次序、最终DOM与rest画质、取消/hidden/deadline语义。不要把12→6提交数当FPS。

## 独立接力与历史压缩

新包本身就是完整可运行游戏，不需旧ZIP、临时目录或累计patch。要精确重建本轮输入的**运行对照副本**，另复制本项目，在副本内用docs/iteration/evidence/round23/baseline/original-runtime-files.json.gz的7份utf8覆盖对应运行入口，并逐项核对docs/iteration/evidence/round23/baseline/runtime-identity.json；这是QA副本，不是第二发行版，当前报告与新QA仍属本轮。全部其它src/资源与输入相同。

19份纯历史JSON现为原路径后加.gz。用 `python scripts/restore-historical-logs-round23.py --help`，只恢复到项目外空目录；不要覆盖游戏树/原档。映射保存所有原始SHA和恢复拒绝测试。原fixture和脚本默认依赖文件没有归档改名。raw RGBA按renderer的xz映射无损读取。

本轮未改变存储层、排序器、RNG、玩法数值、CSS/美术/声音；未完成物理GPU/Windows/手机/读屏/真实听音/OS输入法/物理断电验收。
