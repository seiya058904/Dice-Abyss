# Round23 · v5.22.0 → v5.23.0 · Performance in Focus

本轮主要精力按用户要求用于性能。已证实的收益是背包完整HTML生成更省CPU、固定大数格式器复用、六骰落定不再提交随后立即清除的一整遍绘制。**原生交互结果混合，软件特效长帧未解决，不能宣称整体FPS或普遍提速。** 运行逻辑、完整回归及新解压源码门槛已通过；最终实体另经安全解压与执行身份核对。

## 输入身份与审计

唯一输入 `Dice-Abyss-v5.22.0-cloud-round-22(1).zip`，Round22/v5.22.0，35,661,536字节，3237文件，展开98,302,665字节。

SHA256：`2c6d5fc30641cb5dad9455892b00d75d46eff71adf7cb7d8814af3844db761ac`。

隔离只读基线重新核对CRC、安全路径/类型/预算、3236非自身manifest行及全部原文件。先阅读原STATE/HISTORY和任务书再修改。原顶层18份报告逐字gzip保留；不用历史数字当本轮A/B。没有访问GitHub、部署、远端写入或私人存档。

基线重复开销可直接从代码确认：每个候选重复stats(before)、固定compact locale/options重复格式器、终帧onFrame之后onRest立即覆盖前一遍motion绘制。存档校验/排序缓存、玩法扩表和重做CSS风险较大或无独立收益，未选。本轮四条实际访问一手资料和全领域取舍见RESEARCH。

## 实施与玩家收益

1. **同步批量装备比较**：新增compareEquipmentBatch，一次render只共享当前stats和按需damageExpectation，每件after/结果独立；可见未装备卡使用批量结果。N候选的stats次数2N→N+1；没有持久缓存、可信上下文或公式变化。70件/普通万件/大数万件完整center中位分别减少29.95%/10.20%/52.86%。
2. **固定数字格式器复用**：只复用zh-CN compact formatter，阈值/双Number转换/普通en-US路径及异常语义不变；大数压力收益与batch组合测得，不能重复拆成独立收益。
3. **终帧单次rest提交**：animateDice追加landed标记，保留onFrame→onRest、最终DOM、取消/hidden/deadline；effects直接draw(rest)。两尺寸真实六骰drawElements12→6，静止画质/1800000像素预算与画布赋值2→2不变。仅证明局部工作减少。
4. **保留可复核的性能/兼容证据**：新增2测试模块14案例、3个QA驱动。完整对照51batch/80HTML/28数字边界/原位修改与旧API读取轨迹。旧测试、夹具和脚本不删。19历史纯日志无损gzip，原样恢复19/19及拒绝覆盖验证通过；游戏运行不依赖归档操作。

实际运行/入口差异仅7文件：index.html、package.json、src/release.js（三处版本标识）及engine.js、views.js、dice-motion.js、effects.js。运行净增1526字节。README只更新当前版本介绍，其余保留。没有改变保存schema5/keys/ID/未知字段、RNG消耗、实际结算、概率、内容目录、CSS、音效、字体或素材；没有新运行依赖。完整源保护核对见package证据。

## 撤回与故障处理

face-value查找移到vertex的shader候选及一次整数修订都撤回，renderer最终14522字节逐字等于输入。strict RGBA final-attempt04仍失败：7/12 fixed exact，基线自身恢复4像素差提前中止；current恢复与sourcesAfter未运行。attempt03/04的每个完整buffer SHA分别相同，不能把失败归因为已经撤回的shader。没有容差绿化/裁图/删透明通道；92原始RGBA引用无损保留。撤回理由是等价和独立收益证据不足，不是假称发现可见画质损伤。

终帧重复提交有独立真实GL计数和最终功能生命周期证据，保留为有限工作量优化。正式8/8帧cell当前worst-max更差；6/8不执行修改分支，24对max14慢/10快。两context共用软件后端是未排除混杂，不是根因证明。长帧保留OPEN_RISK，不声称改动没有回退。

## 可比性能概览

同本轮Node24/Chromium155 SwiftShader环境；CPU各24正式对，原生各12对。全分位定义、p95/max、所有负样本见PERFORMANCE。

| 指标 | 输入→当前 | 判断 |
| --- | --- | --- |
| 普通万件完整center CPU中位 | 16.356→14.688ms | −10.20%；22/24对更快，仍有慢对 |
| 大数万件完整center CPU中位 | 23.392→11.026ms | −52.86%；构造压力，不是自然典型库存 |
| 原生万件首开p50 / max | 84.1→75.2 / 105.2→129.3ms | 中心改善、尾部恶化 |
| 原生筛选p50 / 分页p50 | 69.4→67.4 / 49.8→51.9ms | 混合 |
| click→末写中位 | 122.15→121.45ms | 配对中位差−0.15ms，基本持平 |
| 末写→第二rAF p95 | 114.55→139.925ms | 尾部变差 |
| 4K永恒full最坏rAF间隔 | 9421.4→10392.8ms | 软件长帧未解决 |

48主＋14品质窗口全部保留，6745原始间隔。9/48主窗口未观察全full特效阶段（输入4/当前5）；14单次品质覆盖所需阶段观察齐全。不能从常见16.7ms间隔宣传60FPS或物理4K合格。

## 完整回归与玩法检查

输入90模块/840原生案例重跑通过；当前92/854，零失败/取消/跳过/todo。两版各1000标准＋50 noShopping全部10层完成，完整9408字节stdout相同。原固定4×400两版均2/4完成、exit2、923层/13294掷/44死；完整4journeys及15对导出存档只按明确runId归一后相等，原始结果保存。没有改变策略或数值刷完成率。

10功能浏览器job，45结果单位（44case＋1forge group，current42/baseline3）、336明确检查，runtime errors0。覆盖手动战斗、宝箱、刷新、商店/锻造/融合/天赋/事件、原生异常保存/跨标签、v4镜像恢复、四桌面/窄屏、3次原生WebGL恢复及迟到/缺失rAF生命周期。严格像素失败单列，不被功能通过替代。字体当前所需字符缺失为0；人的真实听音/读屏/输入法、物理GPU/手机/Windows未测。

## 包体积、启动与交接

完整游戏保持本地HTML/CSS/JS模块和无依赖Node启动，项目根 `npm start`，按服务器打印的loopback URL打开；无需npm install/build。浏览器QA所需Playwright/Chromium由测试环境提供，不随游戏塞入node_modules。

19纯历史JSON由6,395,468原字节无损变为484,466 gzip字节，加恢复工具/映射后的展开净减少5,893,321字节；这**不是下载减少5.9MB**，ZIP原已压缩这些JSON。原fixture/大字体/许可证/运行素材不删。当前大截图/原始trace/缓存不入包；完整失败RGBA用28对象去重xz保存。输入展开已接近100MB，因此同时保持原100MB展开门槛，未放宽验证器。

最终压缩字节、十进制MB、增长率、文件数在实体打包后实际计算，见最终ZIP标准comment与交付答复；本包不嵌入自己的SHA。源清单排除自身。最终fresh门槛通过后，报告回填重封包只允许报告变化，再核对所有执行文件身份及重新安全解压。fresh解压实际通过166语法模块、92完整默认模块和65项HTTP；原生854案例已单独完整验证。STATE已据实际结果更新COMPLETED/handoffValid，完整日志和执行身份在package/fresh-source-gate。

下一轮直接上传此完整ZIP＋同一任务书；STATE/LATEST_REPORT/VERIFY/PERFORMANCE/BUG_LEDGER/GAMEPLAY_REVIEW/NEXT_ROUND是当前权威。旧专门规则文档可作范围说明，旧轮数字是历史，不能当本轮实测。前五任务：长帧归因、万件尾部、strict像素诊断、pairWard/预算策略、其它深层身份与人的规则理解。
