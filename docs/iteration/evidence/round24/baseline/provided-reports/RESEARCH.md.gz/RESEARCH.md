# Round23 · 性能研究与方案取舍

本轮以用户明确要求“主要精力放在性能优化”为范围依据。唯一游戏基线是上传的 v5.22.0 / Round22 完整包；历史报告是诊断线索，不能当成本轮实测。以下四个一手页面均于 **2026-10-19 UTC** 实际打开并阅读相关正文，没有引用未打开的搜索摘要，也没有复制美术、关卡或游戏文案。

## 来源与实际用途

| 来源 | 阅读要点 | 实际应用与限制 |
| --- | --- | --- |
| [MDN · Number.prototype.toLocaleString](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/toLocaleString) | 相同 locale/options 的重复格式化可复用 Intl.NumberFormat；输出仍由实现与区域规则决定。 | 仅复用固定 zh-CN compact 格式器；阈值、两次 Number 转换和普通 en-US 路径保留。用边界、BigInt、getter、Symbol.toPrimitive 与完整 HTML 对照验证。没有手写“亿/万”规则替代本地化。 |
| [MDN · WebGL best practices](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices) | 不依赖逐片元变化的工作可考虑移至顶点；精度、资源重建与同步成本仍需核对。 | 实际试做 face→value 查询移位，保持几何、UV、材质和预算；严格 RGBA 未通过，连同一次整数恢复修订全部撤回。最终保留单独确认的落地重复提交修复。理论运算减少不能写成 FPS 提升。 |
| [web.dev · Avoid large, complex layouts and layout thrashing](https://web.dev/articles/avoid-large-complex-layouts-and-layout-thrashing) | 交互延迟包含布局、绘制等工作；应避免交错读写造成额外布局。 | 既有局部渲染边界保持；本轮减少完整模板生成中的重复计算。另测真实 click→第二 rAF，避免用 Node HTML 时间替代用户响应。 |
| [MDN · PerformanceLongTaskTiming](https://developer.mozilla.org/en-US/docs/Web/API/PerformanceLongTaskTiming) | long task 记录主线程至少约 50 ms 的任务，不能覆盖所有 GPU 或帧等待。 | long tasks 与 rAF 间隔分别保存；最大帧间隔不能直接命名为同等时长 JS 卡顿。软件后端、固定夹具、预热、配对次序和全部尾部明示。 |

## 候选竞争与全领域复核

等级为本轮定性排序，不是虚构精确收益分数。完整样本、失败与最终数字以 PERFORMANCE、VERIFY 和 evidence/round23 为准。

| 领域 / 候选 | 价值与证据 | 风险 / 成本 | 决策 |
| --- | --- | --- | --- |
| 每张卡重复计算当前构筑 | 可见 N 个候选原先反复计算相同 before 属性；完整 HTML 可逐字核对 | 必须保持候选 after 独立、遗物槽选择与同状态修改可见 | **采用**：同步批量比较；不跨调用缓存，旧公开单品 API 保留。 |
| 深层大数反复构造格式器 | 固定格式、调用密集；原 API 可作等价 oracle | 阈值、两次强制转换与异常语义不可被“简化”改变 | **采用**：只复用 formatter，不缓存数值与输出。 |
| 骰子最后一帧先动再静重复提交 | final rAF 中 onFrame 后紧接 onRest，各画一组，前一组立即被清除 | 最终 DOM 姿态、onRest、取消和 deadline 语义需保留 | **采用**：追加 landed 标记，effects 只提交最终 rest；真实 GL 计数核对。 |
| GPU face 查询移至顶点 | 一手资料与每三顶点同面前提支持候选 | varying、编译和采样精度；独立收益未测定 | **撤回**：严格像素门槛未通过，原着色器完整恢复。原着色器对照本身也有 1 级通道差，不把差异归因为候选的可见损坏。 |
| 万件排序缓存 / 装饰排序 | 排序仍占部分 CPU | Round16 曾因实际浏览器更差撤回；跨状态缓存有失效风险 | **推迟**：selectInventoryItems 原样，不以 Node 单点证明排序成功。 |
| 保存校验或编码次数削减 | 万件提交尾部仍值得研究 | expected 全状态、Web Locks、主镜像与异常一致性是红线 | **本轮不改**：原生提交另测，不能将保存后模板提速归为写盘更快。 |
| 稳定性 / 旧档 | 旧档、未领奖赏、跨标签与异常写已有保护 | 修改事务层会扩大本轮范围 | 保留并回归；schema、keys、RNG、未知字段和 ID 不改。 |
| 玩法 / 经济 / 长程构筑 | 已知零花费策略两条路径停滞，护甲模型有盲区 | 改策略或数值会失去相同轨迹对照 | 原固定策略重跑并保留负结果；下一轮单独预注册预算及 pairWard 模型。 |
| 内容 / 叙事 / 规则理解 | 既有房型、Boss、深层两种规则与提示需保留 | 新机制会改变 RNG 后续路径，掩盖性能归因 | 审查与完整回归，不机械扩表；其余等价变体后续研究。 |
| 视觉 / 交互 / 声音 | 程序化骰子材质、八品质演出与文字可读性是基准 | 新贴图、粒子或降低画质会改变负载与体验 | 实际探索等画面 GPU 方案；最终保留原位图、材质、CSS、字体、音效和像素预算，不增加无用途生图资源。 |

## 实验纪律

固定方案见 evidence/round23/PREREGISTERED.md。正式性能期间不并行运行本任务的单测、模拟或第二个性能浏览器。保留原始计时、慢点、未观察到特效的窗口、驱动失败与撤回候选；只有预先规定的 warmup 不计入正式汇总。物理 GPU、4K60、手机/Windows 和人的听音、输入法体验需要另外验收。

CPU 报告中的 comparisons-* 实际包含 compact state、选择/排序及比较，应标为“选择/排序＋比较”；完整 center 是主要 HTML 生成指标。口径说明单独附加，没有修改原脚本、原报告或重跑替换样本。软件 RGBA 严格对照失败不能用容差绿化，也不能仅凭 1 级通道差断言有肉眼可见问题。
