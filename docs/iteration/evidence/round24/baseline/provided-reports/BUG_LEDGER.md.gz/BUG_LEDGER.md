# Round23 · 问题与开放风险

无新发现的P0/P1发行阻断。完整单测通过不自动等于修复了新Bug。本轮证据以 `evidence/round23/` 为准。

| ID / 级别 | 复现与处理 | 证据及结果 | 状态 |
| --- | --- | --- | --- |
| R23-INV-REPEAT / P2 | 每个可见候选重复计算同一before；同步batch共享before、after独立 | 2N→N+1，51批/80完整HTML等价，普通万件center中位−10.20% | IMPROVED_MEASURED |
| R23-NUM-FORMAT / P2 | 同locale/options大数格式器重复构造；复用固定Intl.NumberFormat | 28边界输入通过；与batch合计大数center中位−52.86%，没有分拆贡献 | IMPROVED_MEASURED |
| R23-TERMINAL-DRAW / P2 | 终帧motion被紧随的rest清除；追加landed、直接提交rest | 两尺寸真实drawElements12→6，7个终帧/渲染案例及生命周期通过，非FPS证据 | FIXED_VERIFIED（重复提交） |
| R23-SHADER / P2 | face查询上移与整数修订无法满足strict gate | 两候选撤回、renderer原字节恢复，失败保留；收益未独立证明 | ROLLED_BACK |
| R23-SOFTWARE-FRAMES / P2 | 8/8当前worst-max更差、9full窗缺观察、最大10392.8ms | 6/8不进改变分支，24对14慢/10快；因果未定，全部负样本保留 | OPEN_RISK |
| R23-PIXEL-ORACLE / P2 | 原renderer还原后仍strict失败，基线自身恢复4像素差 | 7/12 fixed exact；current恢复/sourcesAfter未运行。功能通过不替代 | OPEN_RISK |
| R23-INVENTORY-TAIL / P2 | 首开p50改善但p95/max上升；分页p50变慢 | 各12对全保留；完整DOM/存档等价；无跨状态缓存 | OPEN_RISK |
| R23-SAVE-TAIL / P2 | 末写中位持平，写后rAF等待p95变慢 | 原生锁/expected/主镜像不改，不称保存加速 | OPEN_RISK |
| R23-FIXED-POLICY / P2 | 7919在40层、31676在85层达21死停止 | 两版同原策略2/4完成，exit2不改；历史换甲解困不是本轮重跑 | OPEN_RISK |
| R23-DEEP-CONTENT / P3 | 其它8对等价深层身份、预算/构筑仍待审查 | 本轮规则/RNG不变，不扩表 | OPEN_RISK |
| R23-PHYSICAL-ENV / P3 | 物理GPU/手机/Windows/人的听音读屏/OS输入法/物理断电 | 浏览器模拟不是物理设备认证，断网限页面已加载后 | NOT_TESTED |

## 排除的误报

输入已含Round22 DOM保留及更早写入次数优化，部分旧QA只允许current拥有这些行为会假失败。新inventory-latency驱动针对真实输入修正对照假设，旧脚本原样保留，不算产品Bug修复。

renderer attempt01是Playwright ESM/CJS入口错误，浏览器未启动；改用现有index.mjs另存attempt02。原renderer自身RGBA失败不能称候选shader造成可见损坏/context故障。字体历史修复trace没随输入提供，当前glyph覆盖通过不能冒称历史trace复验。

下轮依NEXT_ROUND排序，不可用删除慢样本、放宽像素阈值、减少完整expected或更改原策略exit2关闭风险。
