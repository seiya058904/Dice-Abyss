# 验收记录 · Round21 / v5.21.0

2026-10-19 UTC。本文只把本轮实际重新执行的检查计入当前结论；旧轮原文保存在 `archives/round20-verify.md`。所有测试、失败和性能各有独立口径，不能相加成为一个虚构总数。原始时间、源码SHA、seed与执行地点在 [证据索引](evidence/round21/README.md)。

## 1. 身份与冻结

唯一输入SHA `30adc2a927be744560825a470538fa7345a6473d1ddce6140ee2e6ec3c84df74`，产品5.20.0/round20/schema5。全部2689文件保持只读不变。当前5.21.0/schema5。

正式当前离线测试冻结170个runtime/test/replay/入口/README/STATE文件，清单SHA `92c37eba88ea68dabcb845e9c82c7ea8c1f84e5116e0262a1400898e2cc501fe`，从12:54:56至13:07:21全部稳定；123继承脚本逐字不变，其他新增脚本保持固定。唯一实时例外是新`qa-battle-windows-round21.mjs`的工具修正，原始及观察到的版本均保留；最终驱动另经浏览器复验与出包语法门禁。最终文档/STATE在离线冻结释放后更新，因此最后还从实体ZIP重跑语法和完整默认测试。

最终性能和规则审计使用：storage `daa6eeffc7a38692213228d748c7819739392a5eeaedc91ec62350c53319591c`；views `75c2b6b0c36ee6d34a8066fc4867c6f223dd630633687a347b703afee674c263`；boon-readout `ea732d4fe897633b67e5349ad57c1bd52dd1506bc84f8db3748eb6aea36f0bfc`。早期候选和风格试验只作为开发证据，不能绑定到最终源码。

## 2. 完整测试与模拟（本轮两版重新执行）

| 命令/口径 | 输入5.20 | 当前5.21 |
| --- | ---: | ---: |
| npm run check | 153模块，4.4644s | 159模块，4.6081s |
| npm test文件包装层 | 82/82，80.7520s | 86/86，111.7179s |
| Node原生TAP细项 | 779/779，81.9465s | 811/811，106.5522s |
| 标准1000+不购物50，每次10层 | 1000/1000+50/50，213.2824s | 1000/1000+50/50，245.0645s |
| 固定4×400层 | 4/4，476.1626s | 4/4，512.3187s |

测试fail/cancelled/skipped/todo均0。82旧模块每个文件SHA和原生计数都与输入相同；新增8匪徒+11首次合格+8存档+5render复用=32。当前短程/长程并行且可能与浏览器正确性并行，以上是任务墙钟耗时，不是游戏提速测量。

短程全部0死亡，完整9409字节stdout两版SHA均 `266fa5b56516410712395796f197a2e33ad1b1e16ede45de14b872f208007d77`，无归一化。长局策略`death-recovery-armor-v2`、预算0、horizon12、最小改善0.05、最多160000决策、死亡上限20均保持原预注册：

| seed | 层数（每版） | 掷骰（每版） | 死亡 | 防具替换 |
| --- | ---: | ---: | ---: | ---: |
| 7919 | 400 | 5422 | 0 | 0 |
| 15838 | 400 | 5034 | 0 | 0 |
| 23757 | 400 | 5612 | 2 | 2 |
| 31676 | 400 | 5528 | 0 | 0 |

总1600层、21596掷、2死亡/2替换；每版11codec往返、256adapter等价比较、64projection检查。7对完整保留保存只归一化top-level runId。报告全schema/字段比较中只有4个开战hash受截路金匪文案影响；原策略32层前缀另捕获完整原状态，重现正式hash后只替换精确enemy.note再全字段比较。不是删除所有叙事字段来强行相等。[strict comparison](evidence/round21/current/deep-comparison.json)

两个短前缀的spawnSync回执同时有exitCode0和EPERM diagnostic，完整新报告、4个seed×32层与保存均生成并通过正式hash匹配；原诊断不删除。正式400层与顶层比较命令退出0且stderr空。前缀不加进400层统计。固定策略不等于人类胜率，历史失败策略不重跑、不伪装成当前新证据。

## 3. 定向与独立检查

| 检查 | 实际范围 |
| --- | --- |
| 匪徒/启明星新原生模块 | 19/19；匪徒8、启明星11 |
| 独立规则/演出 | 397条，含45实际奖励边界、6动画状态 |
| 两版启明星完整状态 | 固定runId下5完整状态/RNG哈希一致；第2/9/24掷真暴击，5次codec往返 |
| 存档事务差分 | 75完整场景；主镜像故障、冲突、导入/恢复/迁移、未知字段 |
| 公共validate/encode | 68场景、20属性读取轨迹；rawJSON/Proxy等反例最终拒绝且0写入 |
| 新render复用 | 130状态/UI场景，780完整HTML逐字相等；无状态/RNG写入、跨调用保持新鲜 |

这些是受控夹具和检查点，不与原生811案例或自然旅程混算。两个失败存档候选及初始工具夹具错误完整保存；完整expected检查没有为了降耗移除。

## 4. 实浏览器及逻辑布局

Linux，Chrome for Testing155.0.8059.84，Playwright，独立context/原生localStorage，loopback4188与4189。Browser连接器/云浏览器无法访问隔离loopback，按任务书授权使用独立Playwright。官方Chrome工具与用户数据不进成品。故障测试明示替身：主写/镜像失败为注入异常，不能声称物理断电；普通保存/操作使用原生storage。

| 当前实际浏览器批次 | 场景 / 检查 | 覆盖 |
| --- | ---: | --- |
| core | 6 / 43 | 新局、亲自掷骰/开箱/换装、刷新、保存恢复、镜像警告、跨标签冲突 |
| interactions选定原场景 | 6 / 44 | 快速点击/空格、锻造/天赋、受保护三遗物融合、商店/付费事件、跨房幸运、V4导入导出归档 |
| pages选定原场景 | 2 / 44 | 八品质实际领取/刷新与30/50/80/140门槛 |
| WebGL | 1 / 4 | 三次上下文丢失恢复、恢复后真实掷骰 |
| environment | 3 / 18 | 离页返回、模拟reduced-motion、已载页面离线操作与本地重新加载 |
| 本轮玩法驱动 | 13玩法场景，46精确手动转换 | 两匪徒0→4掷、6击杀/领奖边界、旧/自定义句刷新、实际点天赋、第9掷首次合格、死亡重燃、多波继承、动画状态 |
| 本轮布局驱动 | 21格 | 7尺寸×0.9/1/1.1缩放；1366/1920/2560/3840、1099、390、320；真实滚动、键盘展开/焦点和动作trial点击 |

五组原场景共18/153，全通过、无page errors。新驱动46次精确动作含8次输入对照和38次当前操作，13玩法829检查与21布局1053检查合计1882，分批去重。输入core另本轮重新通过6/43。新驱动分阶段：第一次34案例5过29失败为错summary选择器；第二次13玩法与8布局通过，另13布局因错误统一12px断言失败。继承战术行CSS最小11px，增益/预览12px，修正后只重跑21布局格，记录每格实际字号与范围。最终采用13玩法+21布局两份成功覆盖，绝不把原失败batch改写成PASS。完整报告、脚本差异、失败原因和截图见证据索引。

字体1,058汉字/21CJK标点均覆盖，两本地字体与8许可相关文件逐字保留；197字体栈检查通过。任意导入文字、实际OS输入法/读屏和物理设备另标NOT_TESTED。

## 5. 性能独立口径

正式测量期间不并行其他CPU/浏览器任务。12对原生万件锁定/保存、12对另一fixture万件打开背包、16主效果窗+14品质扩展窗，全部保留慢样本。源哈希前后稳定，记录3667原始RAF间隔。每格1窗，SwiftShader非物理GPU；保存API返回非物理落盘。保存/DOM完整相等证明正确性，不证明性能改善。端到端目标UNMET，数据、每窗p50/p95/p99/max、longtask与22实际full标记/8low免检见 [PERFORMANCE](PERFORMANCE.md)。

## 6. 成品实体门禁与复跑

最终实体ZIP严格<50,000,000字节，原验证器对CRC、路径/特殊文件、全部manifest字节与SHA、解压后字节逐项验证。清单按完整相对路径字符串排序，唯独排除自身。最终ZIP全新解压后再次执行159模块语法、完整86模块npm test和64HTTP资源检查；实际实体字节/SHA与外部回执在交付时计算，避免自引用。最末文档填入的大小由普通STORE元数据定长回填法再生成核对。

项目根可重跑：

```bash
npm run check
npm test
python scripts/verify-test-cases.py --help
node scripts/simulate.mjs
node scripts/strategy-round18.mjs --source . --output /tmp/round21-deep.json
node scripts/audit-gameplay-round21.mjs . /tmp/round21-gameplay.json
node scripts/audit-battle-render-round21.mjs . /tmp/round21-battle.json
node scripts/smoke-http.mjs --output /tmp/round21-http.json
npm start
```

原生细项驱动实际参数见随包run.json（四worker、每模块原生TAP），不要照抄旧计数。浏览器脚本需要测试者自备Playwright/Chrome并设置PLAYWRIGHT_MODULE/CHROMIUM_PATH；游戏运行不依赖这些测试工具。浏览器和性能重放参数、gzip恢复与源码回溯见证据README。

无已知P0/P1产品阻断；继承npm“Unknown env config http-proxy”告警仍有原stderr。NOT_TESTED：实体GPU/手机、Windows启动器、真实听音/读屏、OS输入法、系统休眠/物理断电；软件布局、故障替身和统计尾部不替代这些验证。
