# Round24 · 问题与机会台账

本轮按性能优先，没有捏造高优先级玩法错误。状态分开表达功能、实际提交数、耗时及严格像素结论；完整数字以 PERFORMANCE/VERIFY 和原始证据为准。

| ID / 级别 | 复现与根因 | 本轮措施 | 状态 / 证据范围 |
| --- | --- | --- | --- |
| R24-DUPLICATE-POSE / P3 | 固定 120Hz 轨迹在更密的回调下多次访问相同采样索引，原版仍提交同一姿态 | dice-motion 仅在同 index、同 GPU/DOM 模式且非终帧时早退；回调后记录实际 GPU 模式 | IMPROVED_MEASURED：19 确定性场景；原生六骰 160/240 供帧调用 1236/1854→930。严格像素另见下行 |
| R24-OFFSCREEN-GL / P3 | 绘制面已在视口外，原 draw 仍更新 buffer 并逐骰提交 | 在已有动态包络上观察整张画布，保留最新 pose，跳过 buffer/GL，回视补画 | FIXED_VERIFIED：三个隐藏姿态 18→0 次 draw，2→0 次尺寸写；终帧、context restore、无 IO 与停止后迟到回调通过 |
| R24-OFFSCREEN-FX / P3 | ROI canvas 离屏仍画粒子/火焰/光效 | 隐藏时只推进时钟和必要闪电序列，跳过主 canvas 与材质重绘 | FIXED_VERIFIED：native current 隐藏窗两类提交增量均 0，正常恢复/到期，无过期重播；两个版本窗口时长不同，不作性能倍率 |
| R24-RECLAIM-EAGER / P3 | 每次背包打开/筛选/分页都计算全包报价，点击确认前还会再计算 | 浏览只显示“检查可回收旧装”；点击再使用现时完整状态生成原报价，确认仍由原交易执行 | IMPROVED_MEASURED（限 CPU/工作消除）：浏览资格读取 1→0，36 HTML/3 handler A/B；万件 Node p50 8.167→7.354ms。原生筛选没有改善，见下行 |
| R24-RECLAIM-MESSAGE / P3 | 开发候选把报价 null 都说成无旧装；合法大数存档也可能因累计数额安全拒绝 | 明确“没有可提交的安全回收批次”，解释无候选或超出安全范围，toast 与公告一致 | FIXED_VERIFIED：1000 件合法高价值装备构造样本及新增真实 handler 测试；未改拒绝规则 |
| R24-CV-ANCHOR / P2 | content-visibility 的占位/已测高度在全 DOM 重绘后变化；设置切换使可见锚点偏移 21–25px | 拒绝 22rem CSS 候选；responsive.css 保持输入字节 | ROLLED_BACK / REJECTED_BEFORE_MERGE：无 CV 控组 176+232 检查通过，同锚点 0px；候选严格保留 1px 阈值与两类失败 |
| R24-INVENTORY-LATENCY / P2 | 同环境 12 对原生筛选 p50/p95 变慢，8 对更慢；Node 工作下降不等于布局/输入下降 | 保留完整样本；追加固定2×2消融32正式+4预热。同新控件移除报价的宽CDP脚本耗时8/8下降，只换控件延迟4快4慢，列表几何一致；据此保留按需计算，但未定位原负结果 | OPEN_RISK：原生筛选 p50 57.1→65.5ms，p95 63.9→73.2ms；后续诊断不替换原A/B，不写回退已修复；打开p95也上升 |
| R24-PIXEL-REPEATABILITY / P2 | motion A/B 严格 RGBA 各 1/4 像素差；同源码同输入 A/A、B/B 也有 4–9 像素差，最大通道差 1、alpha 无差 | 保留 0 容差、完整 RGBA 与原始 exit1，固定 8 次自身复测后停止追加试验 | OPEN_RISK：不能宣称完全像素等价，不能直接把全部差异归因于新代码；5 个离屏/静态 A/B RGBA 精确通过另有记录 |
| R23-SOFTWARE-FRAMES / P2 | 输入记录存在软件渲染秒级长帧；其归因未解决 | 本轮独立 fresh context、同种子、同画质与完整 oracle 重测，所有尾部保留 | OPEN_RISK：最新实测矩阵见 PERFORMANCE，不引用历史负样本冒充当前实测，也不认证物理 FPS |
| R23-FIXED-POLICY / P2 | 原零花费 death-recovery-armor-v2 四旅程只有 2 条到 400 层 | 保留原规则和历史失败，标准 1000+50 短模拟另行重跑 | OPEN_RISK / 本轮长期四旅程 NOT_RUN；不能声称策略或总体平衡已改善 |
| R23-SAVE-TAIL / P2 | 输入记录显示保存后 RAF 尾部问题 | 存档实现保持；保留完整状态、主镜像、异常和竞争回归 | OPEN_RISK / 本轮未另做存储速度基准，不宣称保存提速 |
| R24-DEVICE-ENV / P3 | 云端软件后端和模拟视口覆盖有限 | 标注平台、后端、合成数据、故障注入与实机限制 | NOT_TESTED：物理 GPU/4K60、真实手机、Windows 实机、读屏、声音体验、真实休眠/断电 |

## 验证工具与环境失败

- 连接浏览器与云浏览器均无法访问工作容器 loopback，实际 ERR_CONNECTION_REFUSED；任务书允许的独立本机 Playwright 路径随后可用。
- 首次浏览器 CDN 安装返回短 HTML 而非 ZIP；从官方 Chrome for Testing 当前下载清单获取并校验 Chromium155，浏览器仅作 QA 依赖，不入游戏包。
- baseline HTTP 首次在禁止绑定端口的沙箱报 EPERM；获得本机服务器执行权限后 65 项真实资源验证通过，原失败保留。
- 原生 visibility attempt01 在浏览器启动前遇到 Playwright CommonJS 的 named export 加载错误；使用 createRequire 修正驱动，保存旧驱动与失败说明，attempt02 独立目录记录全部实际结果。
- CSS 原生键盘探索首次按四帧读取时滚动尚未稳定，控组与候选均有过早采样失败；修正的是 QA 等待稳定的条件，最终再跑固定全部场景，原失败保留。
- 静态独立审查在正式测量前修正新帧驱动遗留的旧 inventory 入口、补齐全 HTTP 身份和全新报告目录保护；没有更改旧驱动、旧断言或正式数据。

这些不是被删除的“不利样本”。具体脚本快照、原始记录及与当前结论的对应关系在 `evidence/round24/README.md`。
