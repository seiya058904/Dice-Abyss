# Round25 · 问题与机会台账

本轮把已修复的表现闭环、已减少的工作量、原生延迟分布和严格像素结果分别登记。功能通过不自动变成性能通过；历史失败不会被后续较好的批次覆盖。当前完整回归为 98/98 模块、902/902 原生案例，原 95 个测试模块逐字保留。具体原始记录由 [VERIFY](VERIFY.md) 与 [PERFORMANCE](PERFORMANCE.md) 汇总。

## 本轮问题、措施与状态

| ID / 级别 | 复现与原因 | 本轮措施 | 状态 / 已证实的范围 |
| --- | --- | --- | --- |
| R25-RESIZE-FX / P2 | 已提交事务的表现播放中缩小窗口，输入版三个 FX 场景保留旧几何画布，逻辑尺寸与新容器错位，旧表现仍占用输入 | resize 在 busy 且不处于提交中时走已有表现收束路径，取消旧 generation，展示已提交状态并释放输入 | FIXED_VERIFIED：最终原生 8 场景 / 105 检查通过，含 7 个 active 表现；完整状态、主镜像原字节、旧 canvas 生命周期及重复 resize 检查保留 |
| R25-RESULT-ANNOUNCEMENT / P2 | 开发阶段独立复审发现提前收束可能漏掉尚未发布的结果；把结果统一补发若没有一次性标记，又可能在事件已揭示后重复播报 | 复用各动作原有结果文本，以一次性待播报记录统一正常揭示、resize 与 Skip；事务替换、恢复取消及主档失败保持原边界 | FIXED_VERIFIED：13 个新增真实 app/harness 案例通过，最终 native 七个 active 场景复核；覆盖漏播、重播、镜像警告优先及过期结果取消。原生检查不等于真实读屏设备认证 |
| R25-PAGE-SELECTION / P3 | 连续背包分页重复计算未变化的全包筛选与排序结果 | 仅连续分页复用 app 所有的选择结果；显式筛选、状态/物品数组/run 替换、事务、离开视图与完整重绘使其失效 | IMPROVED_MEASURED，限工作量：7 个新增案例、36 项工作量检查、30 项完整 HTML 对照；保留完整顺序、平局顺序、原状态和存档字节。原生延迟另见下表 |
| R25-PARTICLE-STYLE / P3 | 同一帧相邻同色粒子重复提交相同 fillStyle、strokeStyle、lineWidth | 在每次 drawParticles 调用内按固定 palette key 复用当前 paint state，不重排粒子或跨帧缓存 | IMPROVED_MEASURED，限工作量：6 个新增案例、66 项命令/状态 oracle，通过固定样本减少 46,032 次冗余 setter 提交；不改变路径、alpha、顺序或 RNG。实际帧时与严格像素分别登记 |
| R25-INVENTORY-TAIL / P2 | 全包工作减少后，真实筛选/分页的布局与输入尾部仍有批次差异；最终筛选 p95/max 变慢 | 保留首批分页尾部负样本及最终 12 对完整 A/B，按筛选与分页分别报告，不用合并平均数掩盖退步 | OPEN_RISK：最终筛选 6 快 6 慢，分页 7 快 5 慢；完整 p50/p95/max 见下表。没有宣称背包所有交互都更快 |
| R25-CANVAS-RGBA / P2 | 新原生 Canvas 严格比较 18 项中 1 项不相同，涉及 2 像素 / 2 字节；绿色通道最大差 85、alpha 最大差 1 | 保留首次 0 容差 FAIL 和原始字节；预定 A/A、B/B、A/B 各 3 对诊断，核对差异与 capture 槽位的关系 | OPEN_RISK：17/18 严格 PASS、1 FAIL。追加 9 对均按 capture 槽复现，同槽字节稳定；仍不能写成 18/18 像素等价，也不以槽位相关性替代最终原因说明 |
| R24-PIXEL-REPEATABILITY / P2 | 历史 GL 严格比较中 7 项有 2 项失败 | 原始严格结果、完整 RGBA 与失败记录保留，不放宽阈值 | OPEN_RISK / 历史结果保留：本轮新 Canvas 诊断不覆盖、撤销或改写旧 GL 的 2/7 失败 |
| R23-SOFTWARE-FRAMES / P2 | 软件渲染存在长帧和尾部风险，减少提交不能直接推定实际帧时下降 | 正式基线/当前帧矩阵由整合者串行测量，保留后端、样本、p50/p95/max 与负尾部 | OPEN_RISK：当前数字只引用 [PERFORMANCE](PERFORMANCE.md) 的正式矩阵，本表不猜未完成采样，不认证物理 GPU 或 4K 60 FPS |
| R24-CV-ANCHOR / P2 | 历史 content-visibility 候选导致设置切换时可见锚点偏移 21–25px，违反保留的 1px 阈值 | 该候选已回退，本轮没有重新引入；CSS 保持输入字节 | ROLLED_BACK / 历史回退保留：原候选失败与无 CV 控组证据继续保留，不能把它写成本轮已启用的优化 |
| R23-FIXED-POLICY / P2 | 原零花费 death-recovery-armor-v2 四条 400 层目标仅 2 条完成 | 不改平衡或原策略；本轮重新执行两个原样失败终局的合法续玩，已有 pairWard 防具分支获胜 | OPEN_RISK：自然 4 × 400 本轮 NOT_RUN。182 次动作 / 完整差分 / 精确 codec 复放只证明两个给定终局存在恢复路径，不替换原 2/4 队列结果 |
| R23-SAVE-TAIL / P2 | 历史保存后的输入/RAF 尾部风险仍需专项测量 | 存储实现保持输入；完整回归及六组兼容专项检查主镜像、原始归档、迁移和冲突拒绝 | OPEN_RISK / 本轮未另测保存速度；功能与存档一致性通过不构成保存提速结论 |
| R25-CONTEXT-RESTORE / P2 | 初版两份 context 报告各 25 项检查主要观察 draw count，复审发现“可见 buffer 已恢复”的措辞超出证据 | 最终输入/当前各 3 cycles、31 checks，共 62/62 PASS；同步读取恢复后首个非透明 framebuffer，draw/read 的 GL error 为 0，并核验后续真实命运投掷及两次完整保存 | FIXED_VERIFIED（限最终 QA 范围）：补上真实缓冲证据；相同 partial-frame 恢复捕获不认证完整恢复图像严格一致。保留初版 25 × 2、最终 31 × 2、driver gzip 及四条 readPixels stall warning；不作为性能通过 |
| R24-DEVICE-ENV / P3 | 云端浏览器、软件后端与模拟视口不能覆盖物理设备体验 | 明示后端、调试档、故障注入与真实设备限制 | NOT_TESTED：真实 GPU/物理 4K、手机、Windows 实机、读屏、音频体验、真实休眠/断电；不得扩大 native 浏览器结果的认证范围 |

## 最终背包原生延迟与保留的负样本

最终固定 12 对 A/B 的同类指标如下，单位毫秒，数值顺序为 p50 / p95 / max。

| 交互 | 输入版 | 当前版 | 配对结果 |
| --- | --- | --- | --- |
| 筛选 | 57.0 / 66.8 / 82.5 | 55.6 / 76.7 / 95.7 | 当前 6 对更快、6 对更慢；p95 与最大值退步 |
| 分页 | 43.9 / 49.5 / 59.2 | 43.6 / 47.1 / 51.4 | 当前 7 对更快、5 对更慢；该批 p95/max 改善 |

首批分页尾部退步样本仍保留，最终批次不覆盖它。以上是固定环境与样本的测量，不代表所有背包规模、所有浏览器或每次点击的必然收益；不能把 Node 工作减少、setter 减少或 HTML 相等直接写成浏览器响应同比例提升。

## 验证工具问题、初版失败与修正

- 首次 resize QA 错将受保护的 `package.json` 资源期望为 HTTP 200；按原服务的私有路径策略修正期望为 404。原失败记录保留，服务器没有为通过测试而暴露私有文件。
- renderer-lifecycle 驱动初版动态 import 指向目录而失败；修正为显式 `index.mjs` 后重新执行 11 个场景成功。保留首次失败与修正后报告，不删除错误记录。
- particle oracle 初版对空栈 `restore` 的状态建模不准确；修正为 Canvas 规定的无操作，并在既有新负向案例中补充重复空栈恢复、重复 setter 与实际 primitive paint state 断言。六个粒子案例已在最终完整原生回归中通过。
- context 初版两份 25 检查报告只证明其真实记录的 draw 行为；独立复审后补强为输入/当前各 3 cycles、31 checks，共 62/62 PASS。最终同步首个非透明 framebuffer 的 draw/read 与 GL error、后续真实命运和完整保存均有记录；相同 partial-frame 捕获仍不能认证完整恢复图像严格一致。初版、最终报告、driver gzip 和四条 readPixels stall warning 全部保留，不把两批重复计入功能或性能通过。
- 基线 HTTP 首次本地监听遭沙箱 EPERM，保留原 stderr 后在授权回环监听环境原样重跑通过。当前 npm check/test 的环境 `http-proxy` 配置警告也原样保留，命令均退出 0。

## 历史连续性

输入 `BUG_LEDGER.md` 已按原字节归档于 [round24-bug-ledger.md.gz](archives/round24-bug-ledger.md.gz)，解压后 5,711 字节，SHA-256 `1d66e333766997e1615d146352a8b1785ff66d3afe019164bf86170803222f46`。Round24 的重复姿态、离屏 GL/FX、按需回收及消息修正等既有结论在原文保留；本轮原测试继续执行，不把历史样本重新计为新测量。
