# Round24 · 研究与取舍

访问日期：2026-10-20。以下均为实际打开的一手资料。研究结合上传版的真实实现；没有复制受保护的游戏素材，也没有引入运行框架或网络依赖。

## 已读资料和实际应用

| 一手资料 | 相关实践 | 在本项目中的决定 |
| --- | --- | --- |
| [PixiJS v8 Performance Tips](https://pixijs.com/8.x/guides/concepts/performance-tips) | 离屏剔除本身有 CPU 成本；过滤器、重复文字生成和上传可能昂贵 | 只观察两个已有边界的画布，不给每颗粒子/每个骰面加逐帧矩形查询；先去掉相同采样点的重复提交 |
| [Phaser Scenes](https://docs.phaser.io/phaser/concepts/scenes) | 场景暂停、睡眠、渲染和更新生命周期分开管理 | 借鉴生命周期分离，不照搬 sleep：本游戏交易已先提交，离屏仅暂停实际绘制，演出时间/截止释放仍前进 |
| [MDN Intersection Observer](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API) | 异步观察元素与视口交集，避免滚动处理器反复同步测量 | dice-surface 和最终 ROI 的 scene-fx 使用原生 IO；未知可见性和无 IO 时保守绘制；恢复时只画最新状态 |
| [web.dev content-visibility](https://web.dev/articles/content-visibility) | 离屏内容可以跳过布局和绘制；占位尺寸必须处理，读取布局可能强制计算 | 实际注入并测量 24rem/22rem 候选；耗时有潜力，但 22rem 在设置重绘后产生 21–25px 锚点偏移，因此拒绝合入 |
| [MDN Optimizing canvas](https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Optimizing_canvas) | 缓存重复素材、分离更新频率、减少绘制区域和昂贵操作 | 输入版已有 ROI、材质缓存和像素预算，不能再算作本轮新增；本轮仅在不可见时跳过绘制/缓冲区重分配 |
| [MDN Page Visibility API](https://developer.mozilla.org/en-US/docs/Web/API/Page_Visibility_API) | 文档隐藏与局部元素离屏是不同状态，后台调度需要独立处理 | 保留原 hidden/8 秒 wall deadline/取消和 waiter 清理；局部离屏观察不更改保存或游戏状态 |
| [PixiJS cacheAsTexture](https://pixijs.com/8.x/guides/components/scene-objects/container/cache-as-texture) | 静态复杂内容可缓存；频繁重建缓存会增加开销与显存 | 不给持续变化的骰子/整页加纹理缓存；利用已有静态一次绘制和材质缓存，避免重复建设 |

这些是渲染引擎与浏览器的公开实践，不代表某个商业网页游戏已经为本项目验证过效果。具体收益只引用本轮固定种子、同一源码身份和实测记录。

## 方案竞争

| 候选 | 证据与玩家收益 | 成本/风险/体积 | 决定 |
| --- | --- | --- | --- |
| 相同骰子采样点去重 | 120Hz 轨迹在更密集回调下会重复提交；同姿态无需反复 GL/DOM 更新 | 小范围早退；必须保留 GPU/DOM 切换、音效和终帧 | 实施并做确定性 A/B 与原生 GL 检查 |
| 画布整体离屏跳过 | 已有 ROI 的整体 canvas 可低成本观察 | IO 异步未知期、恢复与生命周期边界需核对 | 实施；持续维护飞行包络和最小效果随机序列 |
| 回收报价按玩家意图计算 | 原版每次背包打开/过滤/分页都检查全包，点击还会再次检查 | 明确改变入口文案；不得缓存陈旧报价或改变保护 | 实施；保留原二次确认和权威交易 |
| 背包 content-visibility | 试测减少实际布局和样式工作，60 个 DOM 子树仍创建 | 不同卡片高度与占位估计导致设置重绘后跳动 | REJECTED：保持原 CSS、原 1px 锚点阈值，失败证据随包 |
| 每帧逐粒子/逐骰面剔除 | 理论上减少小对象绘制 | 同步测量/分支可能超过节省，移动包络易裁边 | 不采用；观察整个表面 |
| 全局暂停离屏游戏逻辑 | 可减少计算 | 会影响已提交结算的展示、按钮解锁与恢复语义 | 不采用；仅控制绘制 |
| 跨帧缓存全包报价/完整状态 | 重用量大 | 锁定、装备和跨标签变更容易陈旧；增加复杂失效规则 | 不采用；改为按需重新计算 |
| 自动降分辨率/削减八品质效果 | 容易降低压力 | 画质与游戏识别度损失，无法证明同等体验下优化 | 不采用；原 shader、像素预算、八品质与字体保留 |

## 本轮领域平衡

稳定性检查集中在取消、context loss/restore、离屏归来和报价确认；交互改善是浏览背包不再自动计算整批交易，以及准确解释安全拒绝。玩法、内容、经济、概率与叙事本轮审阅后保留原规则：没有证据支持为了性能更改六房、手动掷骰或深层掉率。视觉方案比较了整体表面剔除、现有程序化材质/缓存复用和卡片布局跳过；不增加运行位图。后续仍应研究真实硬件上的长帧原因，以及保留失败种子的深层策略，不因连续性能轮次忽视它们。
