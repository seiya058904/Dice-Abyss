# Round25 · 实际验收与明确边界 · v5.25.0

本轮重新执行的输入为 **v5.24.0 / Round24**，当前为 **v5.25.0 / Round25**。输入 ZIP 为 42,305,823 字节、3721 个文件、展开 99,941,262 字节，SHA-256 为 `90784df189c75d0513b6192f2a6ada4c6f1fb199a52d96143112f5a415efd611`。输入本文件的原字节已保存在 [round24-verify.md.gz](archives/round24-verify.md.gz)，其旧轮结果不冒充本轮重测。

本轮源码、规则/存档兼容和已列出的功能检查通过；原生背包延迟仍有混合及负尾部，严格 Canvas 像素仍有失败，长期自然策略和真实设备范围仍有未验收项。**MEASURED 表示已测量，不代表性能通过。** 包内原始记录及压缩映射见第 9 节，最终 ZIP 门槛单列在第 10 节。

## 1. 完整源码与原生案例门禁

| 命令 / 范围 | 输入 v5.24.0 | 当前 v5.25.0 |
| --- | --- | --- |
| `npm run check` | PASS，5.8934 秒 | PASS，5.1019 秒 |
| `npm test` 默认报告 | 95/95 模块包装项 PASS，76.097 秒 | 98/98 模块包装项 PASS，77.4226 秒 |
| `verify-test-cases.py --workers 4` 逐模块原生 TAP | 95/95 模块、876/876 案例 PASS，83.7351 秒 | 98/98 模块、902/902 案例 PASS，命令 78.0536 秒 |
| 显式 1000 seeds 的标准模拟 | 1000 标准 + 50 noShopping，全完成，215.4137 秒 | 相同旅程数，全完成，238.5125 秒 |
| `audit-offline-fonts.py` | PASS，0.6323 秒 | PASS，0.9739 秒 |
| 存档附加兼容专项 | 六组 PASS | 六组 PASS，0.2170 秒 |
| 独立 HTTP 资源检查 | 65 项 PASS | 66 项 PASS |

默认 `npm test` 在本环境报告的是模块包装项；**876/902 是逐一直接运行原生模块所得的案例数**。两种运行不能相加成额外案例。两版原生 TAP 的 fail、cancelled、skipped、todo 均为 0。当前原生计数器内部耗时为 77.9695 秒，表中 78.0536 秒包含命令外层开销；原始起止时间、退出码、stdout/stderr 字节和 SHA 全在命令记录中。上述全部耗时仅为 QA 执行成本，基线部分作业存在重叠，不能用它们作性能 A/B。

原 95 个测试模块保留输入字节。新增三个模块共 **26 个原生案例**：`inventory-page-selection` 7 个、`particle-style-round25` 6 个、`presentation-announcement-round25` 13 个；当前总数为 876 + 26 = 902。当前完整回归前后记录的 76 个运行文件字节保持不变，冻结的 `src/app.js` SHA-256 为 `7c463a2d27ba8a03ebdcef166c3f5988e85febc14173b006b8e84ce893faa7ad`。这组回归身份范围由 `current/source-before.json`、`source-after.json` 和 `source-stability.json` 的压缩原件定义，不能用文件数巧合替代其他保护范围的核验。

基线执行 `node scripts/simulate.mjs 1000`，当前执行 `npm run --silent simulate -- 1000`；**两者都显式传入 1000**，没有把原脚本默认的 500 当作 1000。`--silent` 仅抑制 npm 包装信息。每版都是 1000 条标准旅程加 50 条 noShopping 旅程，每条十层，全部完成且无死亡失败。两版完整模拟 stdout 均为 **9408 字节**，不删字段、不归一化，直接逐字节相同，SHA-256 均为：

`04c1b942a92882602686c9faa0cedcb011ca621a486147e0eb9278916c578721`

完整 stdout 及当前 `simulate-comparison.json` 均随包保留。这个固定短程自动策略的结果不等同于自然长程或人类典型游玩。

## 2. 字体、HTTP 与存档边界

两套必需本地字体均覆盖源码的 **1059 个汉字、21 个 CJK 标点**；**197 项字体栈声明**未发现缺字、畸形栈或绕过本地字体。核心美术素材、字体及许可保持输入原字节。输入缺少的两份历史字体修复记录继续标为 **NOT_AVAILABLE**，本轮覆盖通过不补造历史修复链。

基线 HTTP 检查 65 个资源、当前 66 个资源均通过，涵盖入口、导入/CSS 依赖、MIME、返回字节及私有路径拒绝。当前新增的库存分页模块计入资源检查。基线首次本地监听遭沙箱 EPERM 的 stderr 保留，授权回环监听后重跑通过。`package.json` 按既有服务策略返回 404：resize 驱动早期把它期望为 200 是 QA 错误，已修正期望并保留失败记录，没有改变服务以暴露私有路径。

存档附加专项六组检查覆盖：11 份既有 V4 夹具迁移结果相同、健康主档优先于不同旧镜像、第一次原始归档不可变、不可读但带校验的原件仍可救援、同局同 revision 的分支冲突拒绝且不改磁盘、验证器纯函数及存档 envelope/keys 不变。规则与存储源码保持输入字节，存档 schema 5 不变；浏览器功能报告另验证真实事务和跨标签行为。合成存储专项不模拟真实配额耗尽、操作系统突然断电或所有并发调度。

当前 `npm run check` 与 `npm test` 各自保留 npm 的 `Unknown env config "http-proxy"` 环境警告，均退出 0；没有以清空 stderr 的方式把它们写成无警告运行。

## 3. 当前真实浏览器功能：61 cases/groups、989 checks

下表只合计最终核心、最终 resize 与七条成功的功能作业；组与案例按各驱动原口径记录，**不称为 61 条独立自然旅程**。使用隔离合成存档及真实浏览器动作，到达服务、深层或万件库存的夹具不等于自然游玩到达该处。模拟桌面/窄视口也不等于物理设备认证。页面与交互细节见 [PAGE_REVIEW.md](PAGE_REVIEW.md)。

| 最终报告范围 | Cases / groups | Checks |
| --- | ---: | ---: |
| `current-core` 核心流程 | 6 | 43/43 |
| `resize-current-final` 演出收束 | 8 | 105/105 |
| `inventory-navigation` 库存导航、分页与操作 | 12 | 176/176 |
| `inventory-sync` 同局跨标签同步 | 2 | 13/13 |
| `layout` 布局与窄视口 | 12 | 108/108 |
| `services` 服务/事件交互 | 2 | 21/21 |
| `forge` 锻造 | 3 groups | 286/286 |
| `fusion --quick=true` 融合 | 11 | 119/119 |
| `talents` 天赋 | 5 | 118/118 |
| **合计** | **61** | **989/989** |

七类功能作业自身合计 47 cases/groups、841 checks；加核心 6/43 和 resize 8/105 得到 61/989。其 `commands.json` 还保留早期第八条 lifecycle 作业的依赖导入失败，该失败不计入七条成功作业，也不重复计入最终生命周期结果。融合的 `--quick=true` 仅排除该驱动独立的万件 fusion stress，不能写成这次融合驱动已执行那一项压力场景。

输入核心另有 6 场景、43/43 检查通过。最终 resize 输入版扩展报告为 **8 场景、63 项检查记录，暴露 3 个输入缺陷**；当前为 **8 场景、105/105 检查通过**。早期 resize 批次和 HTTP 期望错误批次保留原样，不再加到最终总数。

最终 resize 包括七个活动演出与一个静态库存场景，活动场景含真实确认后的事件投骰和镜像写入失败。检查结果内容、保存警告、提前结束后的播报、重复 resize 不重复播报、旧异步续段不覆盖新展示，以及完整保存不变。六个由主按钮发起的场景实际检查了收束后的 `focus.id`。新增 13 个原生播报案例还覆盖正常揭晓、提前收束与重复通知边界。这些证据没有扩大到任意控件的焦点恢复或外部读屏软件的实际朗读。

## 4. 生命周期与 context 恢复：单列故障注入

最终 `renderer-lifecycle-final/renderer-lifecycle-browser.json` 为 **11/11 场景 PASS，3 baseline + 8 current**。报告核验既定生命周期条件下的真实提交、最终状态和保存。首次驱动因动态 import 指向目录而失败；显式改为 `index.mjs` 后完成这 11 个场景，原失败及修正后报告都保留。受控 RAF/可见性/截止路径用于验证故障边界，不是性能样本或物理切后台认证，也不额外加入 989 条功能检查。

最终 `context-restore-final` 在输入、当前各完成 **3 cycles、31 checks，共 62/62 checks PASS**。补强检查在真实恢复后的首个非透明 framebuffer 绘制时同步读取像素，并检查 draw/read 的 GL error 为 0；报告同时核验后续真实一次命运投掷及两次完整保存。它补上了初版仅观察 draw count 的不足。

恢复图像记录使用相同的 partial-frame 范围，**不能据此认证完整恢复图像严格像素相同**。报告中的四条 `readPixels` stall warning 原样保留；它们也不是性能结论。初版输入/当前各 25 项检查、最终两版各 31 项检查和实际驱动的 gzip 原件均保留，最终 62 项单列，不把初版 50 项或 context 结果重复加到 989。

## 5. 本轮定向 oracle 与深层复放

分页选择专项保留 36 项工作量检查、30 项 HTML 差分与新增 7 个原生案例：完整筛选/排序和当页渲染语义保持一致，缓存失效边界按既定状态与条件验证。它证明减少可复用的重复选择工作，没有把所有首次翻页称为缓存命中，也不由工作量差额直接推导原生响应提速。

粒子样式专项含 66 项 oracle、新增 6 个原生案例及 46,032 次冗余 setter 减少记录。完整 primitive paint state、顺序和相关边界由 oracle 检查；初版对空栈 `restore` 的错误建模已修正为无操作，原失败保留。这只支持重复样式设置的工作量结论，原生帧尾和严格像素另按第 6 节验收。

深层复放使用历史原样失败终局及原策略输入，本轮实际完成 **182 次合法动作、182 次完整状态差分、182 次精确 codec 比较，全部通过**。两个固定终局在各自对照分支继续失败，而装备库存中已持有的 pairWard 防具后，各自首次重试获胜；不新增物品、不花金币、不改平衡或存档规则。具体终局、分支、逐动作证据与限制见 [GAMEPLAY_REVIEW.md](GAMEPLAY_REVIEW.md) 和 [DEEP_DECISIONS.md](DEEP_DECISIONS.md)。

历史原自然策略四条 400 层目标仍为 **2/4 完成、923 层、44 次死亡**；本轮 **4 × 400 NOT_RUN**。182 次固定终局复放只证明两个给定存档存在合法恢复路径，没有继续自然跑到 400，也没有把原失败队列改写为通过。

## 6. 原生性能与严格失败

本轮 **48 个主帧窗 + 14 个覆盖帧窗**归类为 **MEASURED**。最终统计、样本身份、采样顺序、软件后端与首尾范围以 [PERFORMANCE.md](PERFORMANCE.md) 和其原始记录为准；这里不由测试耗时、draw count、setter 数量或无运行错误推导 FPS 通过。隔离粒子消融单独见该报告，本页不追加提速结论。

最终原生库存每个动作 12 对：筛选 p50/p95/max 从 57/66.8/82.5 ms 到 55.6/76.7/95.7 ms，6 快 6 慢；翻页从 43.9/49.5/59.2 ms 到 43.6/47.1/51.4 ms，7 快 5 慢。筛选尾部仍更慢。首批翻页 p95 51.7 → 53.5 ms、max 55.7 → 66.0 ms 的负样本保留；最终这批不覆盖那一批，不能声称整体提速或全局更流畅。

新 Canvas 原生严格像素 **18 项中 17 PASS、1 FAIL**。失败为 2 pixels / 2 bytes，最大绿色差 85、alpha 差 1；阈值没有放宽，原始严格像素数据保持无损。后续 A/A、B/B、A/B 各 3 对，共 9 对重复诊断均按捕获槽复现差异、槽内稳定；**这些严格比较仍记录 FAIL**。这种归因线索没有取消原 A/B 失败或补成全绿。

历史 GL 严格比较的 **5/7 PASS、2 FAIL** 继续保留，不能用新 Canvas 结果覆盖。历史 content-visibility 候选因 21–25px 锚点偏移被拒绝，原 1px 阈值不变；本轮没有重新启用该候选，CSS 保持输入字节。原失败、回退依据及重复诊断仍可追溯，详见 [BUG_LEDGER.md](BUG_LEDGER.md) 和 PERFORMANCE。

## 7. 明确未验收的范围

真实 GPU、物理 4K60、Windows/手机实机、OS 输入法、人工声音与屏幕阅读器、真实休眠/突然断电均没有完成本轮实机验收。软件浏览器、模拟视口与注入事件仅覆盖报告中明确的范围。

自然深层 4 × 400 本轮未重跑；固定终局恢复不构成平衡或长期完成率的新结论。保存功能与冲突原子性通过，但本轮没有单独测量大存档保存/重读速度，历史保存尾部风险仍开放。严格 Canvas 像素失败、混合原生库存延迟和软件帧尾也没有由功能通过自动关闭。

## 8. 输入运行版本可重建性

已实际执行 `scripts/restore-runtime-baseline-round25.py`，仅使用当前随包文件、输入 runtime manifest 及七份输入原件 gzip，重建后独立与输入核对 **76 个文件、9,733,584 字节，PASS_EXACT_INPUT_RECONSTRUCTION**。范围包含输入全部 `src/`、README、入口、package 和启动/服务脚本；新增的 `src/inventory-page.js` 已排除，输入完整 `src/` 集合相同。验证未运行 `.cmd`。

输入 manifest 与七份回退原件位于 `evidence/round25/baseline/runtime/`，不依赖上一轮 ZIP 或工作区外部数据。这个重建结果与最终 ZIP 的全新解压验收是两种不同门槛，前者通过不会自动完成后者。100 张旧常规截图的有意精简账本及保留原则见 [PACKAGE_REVIEW.md](PACKAGE_REVIEW.md) 与 `evidence/round25/package/omitted-historical-screenshots.json`。

## 9. 随包原始证据与无损映射

以下路径均相对于 `docs/iteration/`。每份原命令、成功及失败的 stdout/stderr 和报告保留原字节；压缩是证据归档，不是改写结果。本来已经 gzip 的文件沿用 `.gz`，不再追加 `.gz.gz`。

| 本轮来源 | 包内位置 / 映射 |
| --- | --- |
| 输入完整回归、字体、存档、模拟及命令记录 | `evidence/round25/baseline/<原文件>.gz` |
| 输入原生案例计数及完整 TAP | `evidence/round25/baseline/native/summary.json.gz`、`native-tap.log.gz` |
| 当前完整回归、逐命令日志、模拟相等证明、字体、存档和运行身份 | `evidence/round25/current/<原文件>.gz`；原本已 gzip 的文件保持原名 |
| 当前 HTTP | `evidence/round25/current/http.json.gz` |
| 核心、resize 各阶段、生命周期及 context 各阶段 | `evidence/round25/browser/<下面列出的原目录>/<原文件>.gz`；原本已 gzip 的文件保持原名 |
| 七类功能浏览器及其命令/依赖失败记录 | `evidence/round25/browser/functional/<current-browser 相对文件>.gz` |

浏览器原目录为：`baseline-core`、`current-core`、`resize-baseline`、`resize-current`、`resize-baseline-extended`、`resize-baseline-extended-fixed-http`、`resize-current-final`、`renderer-lifecycle-final`、`context-restore`、`context-restore-final`。最终合计只使用表中明确的成功批次；HTTP 错误期望、目录导入失败、初版 context 范围不足等原记录留作质量审阅依据，不能重复记成额外成功或独立产品缺陷。

原生性能、严格 RGBA、旧候选失败和深层重建输入分别通过 PERFORMANCE、BUG_LEDGER、GAMEPLAY_REVIEW、DEEP_DECISIONS 的索引访问。旧证据的原文件名/历史标题保留其所属轮次；本页引用不代表重新执行了旧数据。

## 10. 全新提取的源码候选实测与最终实体身份

**实际源码候选门槛已通过**，完成于 2026-10-20T06:36:45.054245+00:00；[完整门槛索引](evidence/round25/package/fresh-source-gate/README.md)及相邻原始命令、stdout/stderr、HTTP、原生TAP和源码身份全部随包。该候选是在报告收口与四份轨迹无损XZ转换前封装的，候选身份不得充当最终下载身份。

| 从候选全新目录执行的项目 | 实际结果 |
| --- | --- |
| 原 `verify-package.py` | CRC、路径/类型/大小写安全、3,850条非自身清单、3,851个提取文件实际字节一致；展开97,998,152字节，预算通过 |
| `npm run check` | exit0，5.4904秒 |
| 原生案例执行器 | 98/98模块、902/902案例，fail/cancelled/skipped/todo均0；83.5424秒 |
| 独立启动HTTP | 实际子服务就绪，66资源、内容/import/CSS URL/MIME/私有404通过 |
| 执行前后 | 候选全部3,851文件及ZIP均逐字不变 |
| 最终工作树绑定 | 328个完整执行文件与候选逐项相同，set SHA `7a611cdcc25e425f88a6cf88b5937bfac2a3080911c53ba526248ebaf2a3da3e` |

这里的3,851和97,998,152都是**候选数据**。最终ZIP实际计数/字节读取其512字节标准comment与包外验证receipt；最终归档自身SHA仅写交付答复/包外receipt，避免循环依赖。最后回填文档、无损证据、STATE和manifest后，最终实体重新提取到另一全新目录，执行原包校验器、语法、完整902案例和66资源HTTP门槛；最后实体通过之前不提供成功交付。

复验时对最终ZIP运行 `python3 scripts/verify-package.py <final.zip> --extract <new-empty-dir> --output <external-receipt.json>`，再从其中的Dice-Abyss目录执行 `npm run check`、`python3 scripts/verify-test-cases.py --root <fresh-Dice-Abyss> --output <external-native-dir> --workers 4` 和 `node scripts/smoke-http.mjs --output <external-http.json>`。所有输出必须在提取项目外；必要时设置空闲的SMOKE_PORT。包校验器不自动替代测试执行器，npm test的模块包装数也不替代原生案例数。
