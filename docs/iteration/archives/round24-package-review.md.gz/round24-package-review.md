# Round23 · 完整包与证据预算

## 输入及保护范围

唯一上传ZIP：35,661,536字节（35.661536十进制MB），3237文件，展开98,302,665字节。SHA256 `2c6d5fc30641cb5dad9455892b00d75d46eff71adf7cb7d8814af3844db761ac`。CRC、安全路径/类型/预算、3236非自身manifest行及原始全文件身份已核对。基线隔离只读，交付不依赖它。

运行入口仅7文件更新，其中3个版本标识、4个实际逻辑文件，净增1526字节。旧90测试、全部旧scripts/fixtures、运行素材、字体及许可证保留；新加2测试模块、3个mjs QA、1个Python历史日志恢复工具。README只改当前版本标记与首段，旧顶层18报告无损归档，HISTORY追加一轮，当前交接报告更新。

## 已执行的无损预算整理

19份历史纯JSON日志保留原路径映射并加.gz：原6,395,468字节→484,466 gzip字节。计入新恢复工具/映射后展开净减少5,893,321字节。19/19实际恢复与输入逐字相同；非空、symlink、项目内部、损坏gzip目标均正确拒绝。原fixture及被旧脚本默认引用的文件没有改名。操作只减少展开空间；旧ZIP已经压缩JSON，不能称下载减少5.9MB。

当前性能/单测/浏览器原始报告用gzip保存；四份长程大报告最终用xz进一步无损压缩，原文件SHA与映射明确。renderer的92个完整RGBA引用按内容去重为28个xz完整buffer，2137108字节，逐对象解码SHA验证；无删alpha/RGB或容差。当前只留两张实际查看的原PNG，共502265字节；重复大图/视频/原始intrusive trace/cache/node_modules不入包。没有改变运行图像/音频/字体的质量。

包内original-runtime-files.json.gz保存7个更改文件的原始UTF8，配合runtime-identity.json可在独立副本精确重建输入的运行源码对照，不需要上一轮ZIP。它不是第二个发行包，当前文档/新QA不伪称历史版本。

## 发行封包规则

原verify-package.py保持不变：ZIP严格 **<50,000,000字节**，目标<=40,000,000；展开<=100,000,000、条目<=10000、无别名/穿越/symlink/cache/嵌套ZIP。FILE_MANIFEST列出全部非自身相对路径、实际bytes/SHA，稳定排序，不自引用。

最终compressed bytes/十进制MB/文件数/展开量/相对输入增长在实体生成后实算，写入最终ZIP固定长度标准comment及交付答复。最终ZIP SHA仅在交付答复，不嵌入自身。不要把候选包或前次包的SHA当最终值。

## 最后门槛

1. 候选完整ZIP经原验证器检查并解压至全新空目录。
2. 从新目录执行npm run check、完整npm test与原HTTP smoke；后者必须从自有子服务器ready开始，核对65运行资源完整字节、相对import/CSS URL/MIME和私有路径404。
3. 将实际源验收回执与日志附入包内后，仅回填报告，不修改任何执行文件；再生成manifest与最终完整ZIP。
4. 最终ZIP重新CRC/全manifest/安全空目录解压，核对全部src/scripts/tests/fixture/字体/资源/入口的执行身份与已经通过的fresh源码逐字相同。报告回填不重复宣称又跑一遍完整测试。

已实际通过fresh源码check/完整npmtest/HTTP，386执行文件前后相同；实际源验收见 `evidence/round23/package/fresh-source-gate/`，最终实体身份见ZIP标准comment及交付。STATE按实际fresh门槛更新；最终实体仍在交付前重新安全解压并验证执行身份。

## 封包阶段实际拦截与修正

第一候选被原verify-package.py以“Manifest must have unique, sorted paths”拒绝；本任务的临时packer按pathlib.Path组件排序，与manifest要求的相对POSIX字符串排序不同。未开始解压或源码执行。已按原断言修正packer并自检，第二候选在全新目录通过CRC/所有manifest哈希/路径与预算/解压字节核验，随后运行完整源门槛。未改游戏、旧测试或验证器，未放宽门槛。第一候选身份和全部逆序对保留在evidence/round23/package/first-candidate-rejection.json，不把失败ZIP嵌套进最终包。

新目录check/test/HTTP均实际exit0，原生854案例全过；临时汇总器因误将92模块数当854案例而自身exit1。按原始日志和386执行文件身份纠正汇总，没有重跑或篡改exit；详见VERIFY与fresh-source-gate/report-collection-correction.json。
