# 下一轮接力起点 · Round24 / v5.24.0

只需本完整 ZIP 与原任务书。先核验 `STATE.json`、`FILE_MANIFEST.json`、实际 package/HTML/release，再从 `LATEST_REPORT.md`、`PERFORMANCE.md`、`VERIFY.md`、`BUG_LEDGER.md` 接续。历史 Round23 顶层报告压缩原件在 `evidence/round24/baseline/provided-reports/`。

## 前五项候选

1. **P2：定位原生交互与长帧尾部。** 本轮减少了明确重复工作，但万件背包筛选 p50 57.1→65.5ms、p95 63.9→73.2ms，12 对中 8 对更慢。追加的固定2×2消融32正式+4预热中，同新控件移除报价的宽CDP脚本耗时8/8下降，只换控件延迟4快4慢；同阶段列表/60卡几何相同。这支持保留按需计算，尚未解释原完整A/B负结果。下一轮从原始样本与这项已完成诊断接续，用有限且预先声明的A/A或追踪区分样式/布局、调度和点击路径，不重复无目标采样或只引用Node CPU。真实硬件GPU仍缺。
2. **P2：稳定背包离屏布局。** content-visibility 候选曾减少布局/绘制，但设置全重绘后锚点偏移 21–25px，原 CSS 同操作为 0。先解决重新创建 DOM 后的固有高度记忆与可见锚点，再谈合入；保留现有 1px 阈值，覆盖真实 wheel、Tab、PageDown/Up/Home/End、深处锁定及弹窗关闭，禁止固定卡高裁掉条件文本。
3. **P2：严格像素重复性根因。** 本轮没有改 shader/网格/像素预算。原生高频供帧 A/B 的严格 RGBA 仍失败；相同版本独立 context 的 A/A、B/B 也各自有 4–9 个像素、每通道至多 1 的差异。应检查 atlas、GL 状态和后端重复性，不能放宽阈值或用 screenshot 肉眼等同严格通过。离屏最新静态画面恢复另有精确通过证据，不要混淆。
4. **P2：深层固定策略与机会成本。** Round23 原 death-recovery-armor-v2 四个 400 层目标只有 2 条完成，另两条在 40/85 层达到死亡停止上限。这是历史已保留失败；本轮未重跑该耗时四旅程，不冒称已解决。规则、概率和 RNG 文件逐字未改。先补策略对 pairWard 等机制的理解，再预注册有限消费预算，保留原零花费策略对照和原种子。
5. **P3：玩家理解和目标设备。** 本轮没有扩房间/掉落表。继续核对深层差异、构筑取舍、实际音效、键盘/读屏、Windows 启动和物理设备表现。以真实体验与可达证据选择内容增量，不机械扩名字。

## 必须保护的行为

- 产品版本与 schema 分开；当前 schema5、原 save keys/装备 ID/未知扩展字段、V1–V4 迁移、完整 expected 快照、Web Locks、主镜像与异常事务路径。
- 手动最多六骰、六房、五装备槽、八品质及 30/50/80/140 门槛、单金币、独立 Lv./+N、死亡保留构筑。
- dawnCrit 已得 nextLuck 跨宝箱/刷新/多波保留，只在下一次实际战斗掷骰消费；离层/重燃清理。
- IO 未报告或不支持时保守绘制。离屏只阻止提交，时钟、取消、hidden、deadline 和按钮释放继续运行。飞行包络仍跟随最新姿态；结束后不重播过期效果。
- 重复采样早退必须包含 GPU/DOM 模式未变且非终帧条件；context loss 期间回退、音效扫描和 onFrame→onRest 顺序不能回退。
- 回收检查读取当时全背包，先展示原完整报价、再确认交易；过滤/搜索不能改变回收范围，保护和金额溢出判断仍由原引擎执行。
- 原 92 个测试模块、旧脚本/fixture、全部本地字体与许可证保持；新定向测试不能替代全量旧回归。

## 启动与复验

在项目根执行 `npm start`，或有 Node 20+ 的 Windows 使用 `启动游戏.cmd`。无需安装运行依赖；公共网站链接是历史部署，不代表此 ZIP 已发布。

基本命令：

```bash
npm run check
npm test
node scripts/simulate.mjs 1000
python3 scripts/verify-test-cases.py --output /tmp/dice-native-next --workers 4
node scripts/smoke-http.mjs --output /tmp/dice-http-next.json
python3 scripts/audit-offline-fonts.py --output /tmp/dice-font-next.json
```

独立 QA 使用测试者提供的 Playwright 与 Chromium，通过 `PLAYWRIGHT_MODULE`、`CHROMIUM_PATH` 指定；它们不是游戏运行依赖，也不能打入成品包。动态 import 的旧生命周期脚本应使用 Playwright 的 ESM 入口 `index.mjs`；新 Round24 驱动用 createRequire，可用 `index.js`。每次报告必须给全新的外部目录，保留失败尝试。

本包可恢复**输入版运行源码**用于复测：

```bash
python3 scripts/restore-runtime-baseline-round24.py --output /tmp/dice-input-round24
```

恢复器校验全部输入运行文件的 SHA，9 个变化文件取随包 gzip 原件，其余取未改运行文件。它不是旧完整项目的伪造副本，不重建历史测试/文档。分别启动恢复版与当前版本机服务器，再从当前项目运行：

- `scripts/audit-inventory-on-demand-round24.mjs`：语义、实际 app handler 与可选 Node CPU 12 对测量。
- `scripts/qa-inventory-latency-round24.mjs`：固定万件背包，12 对 native 打开/筛选/翻页，完整 DOM、存档及 HTTP 身份。
- `scripts/qa-performance-round24.mjs`：先独立 smoke，再固定 48 主帧窗 + 14 品质覆盖窗；不重试替换慢样本。
- `scripts/qa-motion-sampling-round24.mjs`、`scripts/qa-visible-effects-round24.mjs`：确定性 motion 与完整可见 Canvas 命令 A/B。
- `scripts/qa-surface-visibility-round24.mjs`、`scripts/qa-motion-pixel-repeatability-round24.mjs`：原生绘制/恢复与严格零容差诊断；严格失败不是功能通过。
- `scripts/qa-content-visibility-rejected-round24.mjs`：只在隔离 QA 注入已拒绝 CSS；其 exit0 表示缺陷被正确复现，不表示候选合格。
- `scripts/qa-reclaim-factorial-round24.mjs`：固定原27017/null报价夹具，4条件×8blocks，完整记录源码、DOM、存档和计时外几何；仅用于views消融，不替代完整发行版A/B。`--prepare-only`不启动浏览器。

参数见各脚本头部/`--help` 和本轮实际命令回执。正式性能测量应串行，一个测量 context 关闭后再建下一个，不与模拟、全套测试或别的浏览器争用本机资源。

## 本轮范围边界

没有改数值/掉率/游戏 RNG、存档结构、shader/网格/像素预算、字体许可，没有运行依赖或新增美术资产；content-visibility 没有发布。没有物理显卡 4K60、真实手机、Windows 实机、人工声音/读屏或突然断电验收。所有新的报告和完整源码随此单包交付，后续不应依赖会话中的临时目录。
