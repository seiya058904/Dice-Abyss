# 下一轮接力起点 · Round25 / v5.25.0

只需本轮交付的**同一个完整 ZIP 与原任务书**，无需另找补丁、会话临时目录或外部历史 ZIP。先核验 [STATE.json](STATE.json)、[FILE_MANIFEST.json](FILE_MANIFEST.json) 与实际 package/HTML/release，再从 [LATEST_REPORT.md](LATEST_REPORT.md)、[PERFORMANCE.md](PERFORMANCE.md)、[VERIFY.md](VERIFY.md)、[BUG_LEDGER.md](BUG_LEDGER.md) 接续。Round24 输入顶层文档原件已归档到 `archives/round24-*`；其中输入 PAGE_REVIEW 原标题仍为 Round23，不能当作当前验收。

## 前五项候选

1. **P2：定位原生交互慢尾的真实原因。** 最终每动作 12 对：打开 p50/p95/max 77.1/464.4/624 → 72.6/98.4/516 ms，6 快 6 慢；筛选 57/66.8/82.5 → 55.6/76.7/95.7 ms，6 快 6 慢；翻页 43.9/49.5/59.2 → 43.6/47.1/51.4 ms，7 快 5 慢。翻页 CDP 脚本 p50 14.336 → 13.411 ms，但筛选慢尾未解决。首批翻页 p95 51.7 → 53.5、max 55.7 → 66.0 ms 仍是保留的负结果，不能被最终批替代。分段追踪看到每动作一个主要 Layout，尚不支持“反复强制布局”诊断；选择器也已移到 center 包装计时之外，不能直接比较 center 时间。下一轮先声明有限的 A/A 或单因素诊断，核对布局、调度与输入路径，保持完整 DOM/保存/源码身份及所有慢样本，不以 Node 工作量宣称整体提速。帧时原始证据统一从 PERFORMANCE 接续。
2. **P2：补深层多策略与资源使用证据。** 下一轮在保护性能成果的同时，应让游戏性与构筑取舍审计取得更高优先级，平衡近期连续的性能主题。历史零花费 death-recovery-armor-v2 四个 400 层目标仍为 2/4；本轮该 4×400 队列明确 **NOT_RUN**。本轮两份终局的 **182 次合法动作重放通过**，换上已持有的 pairWard 护甲可赢得对应战斗，证明这些具体存档没有不可逆锁死；它不是新的 400 层完成率或平衡通过。保留原种子、原零花费对照和失败轨迹，先改善策略对机制的理解，再预注册有限金币预算、天赋/装备取舍和机会成本比较。本轮 1000 标准 + 50 noShopping 十层运行全部完成，完整 stdout 与输入相同；短程结果也不能替代深层队列。
3. **P2：隔离严格像素差异。** 保留本轮严格 RGBA 负例与同版本重复控制，逐一限定 Canvas/GL 状态、绘制入口和软件后端变量。完整图元状态与几何/顺序等价、context 恢复功能通过，都不能替代零容差像素比较。不得放宽阈值、忽略少量像素或把肉眼截图判断写成严格通过；具体结果与环境从 PERFORMANCE 读取。
4. **P2：先解决可见锚点，再考虑离屏布局。** 此前 content-visibility 候选在设置全重绘后偏移 21–25 px，原 CSS 为 0，候选未发布。维护原 1 px 验收阈值，覆盖 wheel、Tab、PageDown/Up/Home/End、深处锁定及弹窗关闭，验证重建 DOM 后的高度与锚点恢复；不能用固定卡高裁掉条件说明。现有分页缓存不解决这个布局问题。
5. **P3：真实设备与读屏。** 本轮功能汇总为 61 cases/groups / 989 checks，其中 resize 8 项含 7 个活动演出，6 个主按钮场景实查焦点；这是浏览器与 live-region DOM 证据。Windows 启动、物理显卡/手机、音效、输入法和外部读屏仍需真实目标环境。继续关注玩家是否理解实际收益、代价和深层机制，用可复现体验选择内容增量。

## 必须保护的行为

- 产品 v5.25.0 与存档 **schema5** 分开；保留原 save keys、装备 ID、未知扩展字段、V1–V4 迁移、完整 expected 快照、Web Locks、主/镜像写入及异常事务路径。规则、概率和游戏 RNG 本轮原字节未改。
- 保留手动最多六骰、六房、五装备槽、八品质及 30/50/80/140 门槛、单金币、独立 Lv./+N、死亡保留构筑。dawnCrit 的 nextLuck 跨宝箱/刷新/多波保留，只在下一次实际战斗掷骰消费，离层/重燃清理。
- 展示不重新结算。Resize、Skip、hidden/deadline 收束只能显示已提交结果；先取消旧 generation，旧续段不能重放。待发布结果只消费一次，已揭晓不重复，保存警告保留；焦点遵守已有主按钮意图、对话框和用户主动移动规则。
- IO 未知/不支持时保守绘制；离屏只减少提交，时钟、取消和输入释放仍继续。重复姿态早退须保留 GPU/DOM 模式与非终帧条件；context loss 回退/恢复、音效扫描、onFrame→onRest 顺序及真实 Canvas 状态不得回退。
- 回收始终从当时全背包独立报价，完整预览后确认，筛选不改变范围；保护、金额上限及交易验证由原引擎执行。禁止让展示缓存或预览成为保存/交易权威。
- 当前 **98 模块 / 902 原生案例**包括本轮新增 3 模块 / 26 案例；95 个输入模块、97 个输入 tests/fixture 文件及 147 个旧脚本均原字节保留。继续保留旧断言、夹具、负证据、全部本地字体与许可证，新定向测试不替代完整回归。

## 分页缓存的精确契约

`src/inventory-page.js` 只供 app 的库存局部渲染使用；仅 `inventory-page` 传 `pageOnly:true`。缓存键是 state 对象、items 数组、runId 及装备位/品质/规范化查询/生存条件/排序。全页渲染或局部 DOM 回退都会清空，普通 `center(s, ui)` 不回填，因此全页进入库存后第一次直接翻页仍重算；先发生成功的局部筛选，则之后第一次翻页可复用。显式同值 filter、查询提交、清除/重设和实际变更处理仍不传 pageOnly，强制重选。它只省选择器工作，当页比较、HTML、DOM 和其他统计遍历照常。

当前提交状态按新对象替换。缓存不观察同对象字段修改、同数组 push/splice，也不比较 revision/长度；未来增加原地修改时，必须在分页前替换 state/数组、明确 clear 或强制新选择，且不得原地改返回数组。成功事务/导入/换局、差异跨标签同步和恢复保护经全页渲染失效；`act` 主保存失败也会全页重绘，镜像警告仍属于已成功提交。只报告导入失败、未改变 state 的对话框路径不必额外清空。跨标签完整 state 相同且警告未变时保留当前对象并直接返回，允许继续复用；警告改变且非忙碌时重绘清空。不要把“任何 storage 事件都失效”写成约束，也不要把 same-object mutation 当成已支持的透明更新。

## 启动与基本复验

项目根执行 `npm start`，默认地址 **http://127.0.0.1:4188/**；也可在安装 Node 20+ 的 Windows 使用 `启动游戏.cmd`。游戏无需 `npm install` 或第三方运行依赖。端口由 `PORT` 指定，A/B 两版本分别占用不同端口；历史公共网站链接不代表此 ZIP 已发布。

```bash
npm run check
npm test
node scripts/simulate.mjs 1000
python3 scripts/verify-test-cases.py --output /tmp/dice-native-next --workers 4
node scripts/smoke-http.mjs --output /tmp/dice-http-next.json
python3 scripts/audit-offline-fonts.py --output /tmp/dice-font-next.json
```

短模拟必须显式给 `1000`，本轮口径为 1000 标准 + 50 noShopping、各十层。每次 QA 使用全新的项目外输出目录/文件，保留失败尝试。独立浏览器 QA 由测试者在包外提供 Playwright/Chromium，通过 `PLAYWRIGHT_MODULE`、`CHROMIUM_PATH` 指定；不得把 node_modules、浏览器、缓存或原始开发临时文件打进游戏 ZIP。旧动态 import 驱动使用 Playwright ESM `index.mjs`，采用 createRequire 的驱动可使用 `index.js`，以各脚本头部为准。

## 只用本包恢复输入版

```bash
python3 scripts/restore-runtime-baseline-round25.py --verify-only
python3 scripts/restore-runtime-baseline-round25.py --output /tmp/dice-input-round25
```

输出目录必须尚不存在且位于项目外。恢复器在写出前验证 **76 个输入文件 / 9,733,584 B**：包含 v5.24.0 运行源码、README、资源与启动文件，7 个变化文件取随包 gzip 原件，其余 69 个取逐 SHA 相同的当前文件；不加入新 `inventory-page.js`。恢复范围不含旧完整测试/文档，不能在该运行树上声称重跑了历史完整测试。

分别启动恢复版与当前版服务器，从当前完整项目调用下列驱动；参数见源码头部和 VERIFY 中实际回执。

- `audit-inventory-page-round25.mjs`：重复选择工作量、完整顺序/HTML/保存等价；计数不等于原生延迟。
- `qa-inventory-phases-round25.mjs`：分段与 Layout 诊断；有包装注入，不作为发行版正式速度。
- `qa-inventory-latency-round24.mjs`：保留原驱动，万件库存每动作 12 对 native A/B、完整 DOM/保存与 HTTP 身份。
- `qa-resize-settlement-round25.mjs`：已提交演出的真实 resize、结果/警告、主按钮焦点、旧续段与静态库存。
- `audit-particle-style-round25.mjs`、`qa-context-restore-round25.mjs`：画笔状态与实际 context loss/restore；各自验证边界不能混成像素或 FPS 结论。
- `qa-performance-round24.mjs` 及保留的 motion/visibility/pixel 驱动：按 PERFORMANCE 的协议与原始结果接续；不得用追加更好样本覆盖已声明的正式批。

正式性能测量串行运行，不与全套测试、模拟或其他浏览器争用资源。本轮没有发布 content-visibility，没有新增游戏运行依赖或美术降级；物理 GPU 4K60、真实手机、Windows 实机、人工听音/读屏和突然断电均不在本轮认证范围。交付继续使用同一完整 ZIP，完整源码、许可证、报告与恢复材料一并随包；最终文件身份与归档体积以交付 manifest 和打包验收为准。

字体QA另需测试环境提供Python `fontTools`；审计可使用Node内建Brotli回退，不要求Python Brotli扩展。这是开发验证依赖，游戏本身仍无需安装运行依赖。
