# Round25 · 研究、方案竞争与证据边界

访问日期：2026-10-20。本轮只以上传的 v5.24.0 / Round24 为输入；以下资料由本轮审计或主流程实际打开阅读；后三条布局/性能资料由主流程在同日查阅。公开 API 资料用于理解机制，项目收益仍需同输入源码、同场景的实测支持。没有引入运行框架、在线依赖或他人游戏素材。

## 一手资料与实际应用

| 实际查阅的一手资料 | 相关事实 | 本轮采用与取舍 |
| --- | --- | --- |
| [MDN · Optimizing canvas](https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Optimizing_canvas) | 不必要的 Canvas 状态改变有开销；重复素材缓存和缩小绘制区域是常见优化方向。 | 输入已有 ROI、材质缓存和像素预算，本轮不重复计功。只减少连续相同的粒子样式写入；不采用取整坐标、改采样尺寸等会改变外观的做法。 |
| [web.dev · Improving HTML5 Canvas performance](https://web.dev/articles/canvas-performance) | Canvas 维护绘制状态；状态提交和绘制批处理有成本，浏览器与硬件加速变化要求重新测量。 | 采用局部状态复用。因合成顺序可能影响有限精度结果，不按颜色全局重排粒子。文章历史性能数字不当作本项目当前收益。 |
| [MDN · WebGLRenderingContext.disable](https://developer.mozilla.org/en-US/docs/Web/API/WebGLRenderingContext/disable) | DITHER 是可控制的 WebGL 能力，会影响写入颜色缓冲区前的颜色处理。 | 仅作为历轮微小 RGBA 不重复的研究线索。没有隔离证据证明根因，本轮不修改 DITHER、shader 或严格容差，也不把历史 FAIL 改为 PASS。 |
| [MDN · ResizeObserver](https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver) | 可以观察元素尺寸；回调中改变尺寸需要处理循环触发。 | 骰子已有元素观察机制。FX 的问题在演出创建时保留了局部坐标；本轮不增加第二套观察器和重建生命周期。此选择是结合本项目已提交事务语义作出的判断。 |
| [MDN · Window: resize event](https://developer.mozilla.org/en-US/docs/Web/API/Window/resize_event) | window resize 反映视图尺寸变化；元素尺寸变化另由 ResizeObserver 处理。 | 对真实 window resize，忙碌且未处于提交中的演出沿用现有结束路径。原生验证用实际 `page.setViewportSize`，没有用手工派发事件替代尺寸变化。范围是窗口缩放，不宣称所有内部布局变化都能自动重建 FX。 |
| [web.dev · Avoid large, complex layouts and layout thrashing](https://web.dev/articles/avoid-large-complex-layouts-and-layout-thrashing) | 布局规模和读写交错会影响交互；重复强制布局需要由实际执行轨迹确认。 | 原生 trace 见单动作一次主要 Layout，没有据一次大布局就下 thrashing 结论，不盲目重排恢复调用或重复前轮 CSS 候选。 |
| [web.dev · Manually diagnose slow interactions in the lab](https://web.dev/articles/manually-diagnose-slow-interactions-in-the-lab) | 实验室诊断需区分输入等待、处理工作与呈现等待，并观察完整交互。 | 沿用可信 click 到第二 RAF 的完整延迟；首次 RAF、CDP 较宽观察窗口和阶段 wrapper 各保留边界，不把 center span 或 ScriptDuration 单列当整体收益。 |
| [MDN · Long animation frame timing](https://developer.mozilla.org/en-US/docs/Web/API/Performance_API/Long_animation_frame_timing) | Long Animation Frame 可提供整帧及脚本相关诊断信息，与单个长任务记录的范围不同。 | 本轮实际探针为 RAF + LongTask，没有新增 LoAF 观测。LongTask=0 的长 RAF gap 仍保留，不伪称已取得 LoAF 脚本归因或确认 GPU 根因。 |

## 候选竞争

| 候选 | 证据与成本 | 决定 |
| --- | --- | --- |
| 连续同调色板粒子复用三项 Canvas 状态 | 小范围、无新素材。局部标记每次调用重置，保留换色、跨帧和方形粒子 save/restore。66 个确定性对照案例 PASS。 | 经一次固定消融后保留；完整记录对照通过，原生 p95 改善和性能不劣均未证明，两个 full 中位数偏慢保留 OPEN_RISK。 |
| 库存连续翻页复用一次完整筛选结果 | 上一页/下一页仍对同一已提交状态和相同条件做全包筛选排序。缓存仅一份，比较状态对象、物品数组、runId 和标准化条件；完整重绘清空，显式筛选/搜索重新计算。 | 保留可证实的重复选择器工作清理；最终翻页 7/12 对更快，整体输入收益混合，初批与最终筛选等负值分别保留。普通 view 调用保持无缓存；比较和交易不使用缓存报价。首次完整打开不预填缓存，紧接的第一次翻页仍可能计算。 |
| 重排库存位置恢复或再改 DOM 协调 | 已有 60 项分页和相同 DOM 保留属于输入功能。根因诊断中 6 个动作对应 6 次主要 Layout，改变恢复顺序可能只是移动同一次必需布局。 | 没有足够因果证据支持额外布局改动；不把旧 DOM 协调算作新增优化。诊断包装器的耗时不作为正式用户延迟。 |
| 窗口缩放时一次结束旧演出 | 输入原生复现 3 个 FX 尺寸错位；事务在动画前已完成。沿用 generation 失效与取消逻辑，可显示已提交结果，无需新 RNG 或保存写入。 | 实施；最终当前 8 场景 / 105 项原生检查通过；输入扩展 8 场景 / 63 项检查仍复现 3 处几何错位。重复缩放不会持续重建，静态库存保留现有节点。 |
| 新大贴图、减少粒子或降低画布分辨率 | 增加资源或改变画质；现有缓存已解决部分同类工作。 | 不采用，无新位图。 |
| content-visibility 或逐粒子复杂剔除 | 上轮占位方案已有锚点失败；逐对象判断又增加成本与裁边边界。 | 不重复上轮失败候选，也不放宽锚点阈值。保留现有整体表面可见性机制。 |
| 修改 GL 抖动、shader 或视觉时间步进 | 尚未把原生微小像素不重复与软件长帧隔离为单一根因；变化可能影响视觉。 | 不采用；保留原失败和长尾记录，等待可分离的原生证据。 |

## 当前可确认的结果

粒子对照使用真实上传源码，比较的不是删减后的画面内容。审计只移除 fillStyle、strokeStyle、lineWidth 的已相等重复写入，其他命令、路径、变换、透明度与顺序保持严格一致，并独立比较每次 primitive 的记录状态。4 个视口、16 种效果和 2 个取消案例合计少 46,032 次样式写入。新审计器的空栈 restore 已按原生语义改为保持状态，两个针对性的 oracle 测试再次通过；没有修改旧测试来掩盖变化。以上属于受控提交证据，不是原生 FPS 结论。

缩放的原生输入扩展复现为 **8 场景 / 63 检查**，Boss 爆发、开箱蓄力和永恒揭示仍记录 3 处实际旧尺寸错位。最终当前版为 **8 场景 / 105 检查 PASS**，检查完整引擎预期状态、主/镜像原字节、旧画布脱离、重复缩放、有界延后回调、提交结果播报与镜像警告。六个主按钮发起的场景原生确认焦点回到主按钮；事件选项沿用既有焦点政策，不宣称恢复任意按钮。初版 43 项检查没有测实际焦点，最终报告已补上这一项；真实外部读屏效果仍未认证。场景使用合成 fixture，不宣称自然通关深层。证据为 `resize-current-final/report.json` 与 `resize-baseline-extended-fixed-http/report.json`。

主流程已知的其它最终功能记录为：核心 **6 场景 / 43 检查 PASS**，其它浏览器功能 **47 组 / 841 检查 PASS**；渲染生命周期为输入 3 + 当前 8，共 **11 场景 PASS**。这些脚本的场景/分组口径分别保留，详见 VERIFY 和 `renderer-lifecycle-final/renderer-lifecycle-browser.json`，不据生命周期墙钟时间声称帧率收益。

原生 context 恢复初版完成输入、当前各 **3 周期 / 25 检查 PASS**，原结果及驱动精确 gzip 保留。独立静态复审指出 drawElements 次数与非零 buffer 尺寸不足以证明非透明像素，存档快照也不是写入次数 oracle，因此只修正新 QA：loss 后记录独立 draw 基线，恢复 native draw 同一调用中即时 readPixels，避免 preserveDrawingBuffer=false 的异步清空误读；只在恢复功能阶段采样，console warning 单列。

[最终加强探针](evidence/round25/browser/context-restore-final/report.json.gz) 已由主流程在独立原生任务完成：两版各 **3 周期 / 31 检查，合计 62 PASS**，实际读回 alpha>0，采样 draw/read GL 错误 0，存档原字节快照及随后一次手动动作通过。**4 条 ReadPixels stall warning 原样保留**；它们来自功能读回，不进入正式性能样本。首个非透明采样可能是第一颗骰子的部分帧，故不认证完整双骰图像、严格 RGBA 恢复、每次后续 GL 调用或最终 CSS 可见性。

原生 Canvas RGBA 的输入 A/B 记录为 **17/18 严格通过**；保留 4K `loot-7`、300 ms 的 2 字节/2 像素负例。按原脚本和 0 容差，仅该场景各做 3 对输入/输入、当前/当前、输入/当前对照，**3 组共 9 对全部重现原差异**。18 份新增完整 RGBA 按第一/第二采集槽与原负例逐字节一致；同一槽内重复稳定，跨槽不同，源码版本不是本次差异出现的必要条件。不能由此宣称全部像素等价、随机误差已消除或已定位浏览器根因。原始失败、完整 buffer、源码身份与无错误记录均保留，汇总见 `pixel-repeat-round25.json` 及三组原生报告。

两个变动像素的 alpha 分别只有 3 与 1。结合原始像素邻域、截图位置和 `rewardRims` 源码，静态线索指向战利品卡右侧边缘缓存的下端；尚未做逐层原生读回，故不把这个线索写成根因结论。另实际查阅 [WHATWG HTML · Premultiplied alpha and the 2D rendering context](https://html.spec.whatwg.org/multipage/canvas.html#premultiplied-alpha-and-the-2d-rendering-context)：Canvas2D 输出使用预乘透明度，有限精度下与非预乘表示的转换会损失信息。这解释低 alpha 通道差异可能放大的数学背景，不证明本次哪个实现阶段产生了差异，更不构成放宽判定的理由。

## 正式数据如何改变取舍

[主帧矩阵](evidence/round25/performance/frames-final/performance-round.json.gz) 是完整输入发行版对完整当前发行版，**48 主窗 + 14 品质覆盖**，MEASURED、源码稳定、错误 0、预期特效全部观察到。8 个场景格中 **5 格 run-p95 中位数更慢**，24 个配对 **9 快 / 14 慢 / 1 相同**；1080p Boss full 为 3/3 p95 同向变慢。max 配对为 18 快 / 6 慢，但有 3/8 格的组内最坏值变差。LongTask 数量 10→8，总重叠时间却 **2,362→2,774 ms**；不能用工作量减少或任务数减少遮住这些负值。4K 永恒本批尾部较好不构成粒子因果证明。

为隔离这项改动，预先固定一次 [单变量消融](evidence/round25/performance/particle-ablation/performance-round.json.gz)：两端采用最终当前运行代码，控制端仅换回真实输入 effects.js，实际身份清单确认唯一运行差异。1920×1080、Boss/永恒、full/low、3 对，共 **24 主窗 + 14 单独品质覆盖**，同一旧帧驱动、AB/BA，不重试择优、不与原主矩阵合并。全部 12 对 p95 为 8 快 / 4 慢；实际执行粒子分支的 full 为 4 快 / 2 慢，原 Boss 3/3 同向退化未重现。

反方数据同样保留：消融 Boss full 的 run-p95 中位 **22.0→22.6 ms（+2.73%）**，永恒 full **19.5→20.4 ms（+4.62%）**；未执行粒子分支的 low 也出现混合方向及永恒 max 662.8→782.0 ms。边际中位数和配对差的统计目标不同，不能只选较有利的一种。**最终保留局部 setter 清理，只以受保护的可证实工作量减少为理由；原生 p95 收益、性能不劣及长尾根因均未证明，风险为 OPEN_RISK。** 不继续补测有利样本；后续若有可复现单变量退化，应优先重新评估这项低范围清理。

[最终库存报告](evidence/round25/performance/inventory-latency-final/report.json.gz) 为 72 正式动作、另 6 固定预热、12 对/动作。翻页 p50 **43.9→43.6 ms**、p95 **49.5→47.1 ms**、max **59.2→51.4 ms**，7 快 / 5 慢；筛选 p95 **66.8→76.7 ms（+14.82%）**、max **82.5→95.7 ms**，打开为 6 快 / 6 慢。较宽 CDP 的翻页 ScriptDuration p50 **14.336→13.411 ms** 与少做 selector 的方向一致，不能替代严格延迟或掩盖布局/TaskDuration 的负值。

[初批库存](evidence/round25/performance/inventory-latency/report.json.gz) 独立保留：打开 p50 72.5→73.3 ms，筛选 p95 79.3→80.1 ms，翻页 p95 **51.7→53.5 ms**、max **55.7→66.0 ms**、LongTask **1→2**。最终批次没有覆盖初批。工作量探针的 36 计数行和 30 个完整 HTML/存档对照支持只删 selector 重复工作；不会检测任意同对象就地变异，现有动作的失效契约与首次冷路径继续保留。

[PERFORMANCE](PERFORMANCE.md) 给出每格输入/当前 run-p95、最坏 max、run-p50/p99、完整原始 RAF 所在、配对方向、全部 CDP 列及两批负结果。严格像素 **17/18** 与 9 对复验失败继续开放；完整 RGBA 由 `visual/rgba-manifest.json` 对应的标准 gzip/xz 无损对象保留，不因去重或重压缩改变判定。物理 GPU、Windows、实体手机和外部读屏结论仍需相应环境验收。

## 领域与历史记录

本轮保留玩法、内容、经济、掉率、RNG 和存档结构。性能改动集中在可以明确省掉的重复工作；稳定性改动处理窗口缩放后的过时演出。没有为了扩大改动范围而新增房间、装备、叙事或改写深层策略。现有美术与字体继续使用，具体资源说明见 ART；包体整理与性能改动分开记账。

输入 RESEARCH.md 已按原字节归档到 `archives/round24-research.md.gz`，解压后与输入一致。上轮研究及拒绝结果保留在该归档，不冒充本轮新实验。
